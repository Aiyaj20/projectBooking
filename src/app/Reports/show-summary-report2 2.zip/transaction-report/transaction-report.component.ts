import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NzTableQueryParams } from 'ng-zorro-antd/table';
import { ClientmasterService } from 'src/app/Services/clientmaster.service';
import { ExportService } from 'src/app/export.service';

@Component({
  selector: 'app-transaction-report',
  templateUrl: './transaction-report.component.html',
  styleUrls: ['./transaction-report.component.css'],
})
export class TransactionReportComponent implements OnInit {
  isFilterApplied: any = 'default';
  totalRecords: any;
  pageSize = 10;
  pageIndex = 1;
  sortKey: string = 'id';
  sortValue: string = 'desc';
  searchText: any = '';
  loadingRecords = true;
  filterClass: string = 'filter-invisible';
  isSpinning = false;
  bookingdetails: any = [];
  transactionExcelList: any = [];
  query: any;
  pageSize2 = 10;
  THEATRE_ID: any;
  DRAMA_ID: [] = [];
  show: any = [];
  category: any;
  NAME: any;
  ID: any;
  theater: any = [];
  columns: string[][] = [
    ['THEATRE_NAME', 'THEATRE_NAME'],
    ['SHOW_NAME', 'SHOW_NAME'],
    ['BOOKING_ID', 'BOOKING_ID'],
    ['SEAT_NUMBERS', 'SEAT_NUMBERS '],
    ['PAYMENT_DATE_TIME', 'PAYMENT_DATE_TIME'],
    ['PAYMENT_GATEWAY_ID', 'PAYMENT_GATEWAY_ID'],
    ['TOTAL_AMOUNT', 'TOTAL_AMOUNT'],
    ['GROUP_LAYOUT_NAME', 'GROUP_LAYOUT_NAME'],
  ];

  dateFormat = 'dd/MM/yyyy';

  selectedDate: any = [];
  startValue: any;
  endValue: any;

  today =
    new Date().getFullYear().toString() +
    '-' +
    (new Date().getMonth() + 1).toString() +
    '-' +
    new Date().getDate().toString();

  current = new Date();
  month = this.today;
  filterQuery: any;
  // filterQuery = "AND DATE(PAYMENT_DATE_TIME) = '" + this.month + "'";

  constructor(
    public api: ClientmasterService,
    private message: NzNotificationService,
    private datePipe: DatePipe,
    private _exportService: ExportService
  ) {}

  ngOnInit(): void {
    this.gettheatername();
    this.getshowname();
    // const today = new Date();
    //  this.startValue = this.formatDate(today);
    //    this.endValue = this.formatDate(today);
    // this.search();
    this.selectedDate[0] = new Date();
    this.selectedDate[1] = new Date();
    this.DateChange(this.selectedDate);
    // this.startValue = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    // this.endValue = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.applyFilter();
  }

  // formatDate(date: Date | null): string {
  //   if (!date) {
  //     return '';
  //   }
  //   const year = date.getFullYear().toString();
  //   const month = (date.getMonth() + 1).toString().padStart(2, '0');
  //   const day = date.getDate().toString().padStart(2, '0');
  //   return `${year}-${month}-${day}`;
  // }

  keyup(event: any) {
    this.search();
  }

  onKeypressEvent(reset: any) {
    const element = window.document.getElementById('button');
    if (element != null) element.focus();
    this.search();
  }

  gettheatername() {
    this.api.getTheatreMaster(0, 0, '', '', 'AND STATUS = 1').subscribe(
      (data) => {
        if (data['code'] == 200) {
          this.theater = data['data'];
        } else {
          this.message.error("Can't Load Theater Name", '');
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  selectedShowNames: number[] = [];
  getshowname() {
    this.api.getdramaMaster(0, 0, '', '', 'AND STATUS = 1').subscribe(
      (data) => {
        if (data['code'] == 200) {
          this.show = data['data'];
        } else {
          this.message.error("Can't Load Show Name", '');
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  search(reset: boolean = false, exportInExcel: boolean = false) {
    if (reset) {
    }
    // this.filterQuery = "AND DATE(PAYMENT_DATE_TIME) = '" + this.month + "'";
    this.loadingRecords = true;
    var sort: string;
    try {
      sort = this.sortValue.startsWith('a') ? 'asc' : 'desc';
    } catch (error) {
      sort = '';
    }
    var likeQuery = '';
    console.log('search text:' + this.searchText);
    if (this.searchText != '') {
      likeQuery = ' AND(';
      this.columns.forEach((column) => {
        likeQuery += ' ' + column[0] + " like '%" + this.searchText + "%' OR";
      });
      likeQuery = likeQuery.substring(0, likeQuery.length - 2) + ')';
      console.log('likeQuery' + likeQuery);
    }
    var filter = '';
    if (likeQuery) filter = this.filterQuery + likeQuery;
    else filter = this.filterQuery;
    this.query = likeQuery;

    if (exportInExcel == false) {
      this.api
        .getcarttransaction(
          this.pageIndex,
          this.pageSize,
          this.sortKey,
          sort,
          likeQuery + this.filterQuery
        )
        .subscribe(
          (data) => {
            if (data['code'] == 200) {
              console.log('Prachi');

              this.loadingRecords = false;
              this.totalRecords = data['count'];
              this.bookingdetails = data['data'];
              console.log(this.bookingdetails, 'booking details');
            } else {
              // this.message.error('Something Went Wrong', '');
              this.loadingRecords = false;
            }
          },
          (err) => {
            console.log(err);
          }
        );
    } else {
      this.api
        .getcarttransaction(
          0,
          0,
          this.sortKey,
          sort,
          likeQuery + this.filterQuery
        )
        .subscribe(
          (data) => {
            if (data['code'] == 200) {
              console.log('Pranali');

              this.loadingRecords = false;
              this.transactionExcelList = data['data'];
              this.exportexcel();
            }
          },
          (err) => {
            if (err['ok'] == false) this.message.error('Server Not Found', '');
          }
        );
    }

    // this.api.getcarttransaction(this.pageIndex, this.pageSize, this.sortKey, sort, likeQuery + this.filterQuery).subscribe(
    //   (data) => {
    //     if (data['code'] == 200) {
    //       this.loadingRecords = false;
    //       this.totalRecords = data['count'];
    //       this.bookingdetails = data['data'];
    //       console.log(this.bookingdetails, 'booking details')
    //     } else {
    //       this.message.error('Something Went Wrong', '');
    //       this.loadingRecords = false;
    //     }
    //   },
    //   (err) => {
    //     console.log(err);
    //   }
    // );
  }

  showFilter() {
    if (this.filterClass === 'filter-visible')
      this.filterClass = 'filter-invisible';
    else this.filterClass = 'filter-visible';
  }

  endOpen = false;

  applyFilter() {
    console.log('asdfg = ', this.DRAMA_ID);


    var sort: string;
    try {
      sort = this.sortValue.startsWith('a') ? 'asc' : 'desc';
    } catch (error) {
      sort = '';
    }

    if (
      this.startValue != undefined &&
      this.startValue != null &&
      this.THEATRE_ID != undefined &&
      this.DRAMA_ID.length != 0
    ) {
      this.filterQuery =
        "AND DATE( PAYMENT_DATE_TIME ) BETWEEN '" +
        this.startValue +
        "' AND '" +
        this.endValue +
        "') AND THEATRE_ID = '" +
        this.THEATRE_ID +
        "'AND SHOW_ID IN ('" +
        this.DRAMA_ID +
        "')";
      this.filterClass = 'filter-invisible';
      this.isFilterApplied = 'primary';
      this.loadingRecords = true;
      this.search(true);
    } else if (
      this.startValue != undefined &&
      this.endValue != undefined &&
      this.THEATRE_ID != undefined
    ) {
      this.filterQuery =
        " AND DATE( PAYMENT_DATE_TIME ) BETWEEN '" +
        this.startValue +
        "' AND '" +
        this.endValue +
        "' AND THEATRE_ID = ' " +
        this.THEATRE_ID +
        " ' ";
      this.filterClass = 'filter-invisible';
      this.isFilterApplied = 'primary';
      this.loadingRecords = true;
      this.search(true);
    } else if (
      this.startValue != undefined &&
      this.endValue != undefined &&
      this.DRAMA_ID.length != 0
    ) {
      this.filterQuery =
        " AND DATE( PAYMENT_DATE_TIME ) BETWEEN '" +
        this.startValue +
        "' AND '" +
        this.endValue +
        "' AND SHOW_ID IN ('" +
        this.DRAMA_ID +
        "')";
      this.filterClass = 'filter-invisible';
      this.isFilterApplied = 'primary';
      this.loadingRecords = true;
      this.search(true);
    } else if (this.THEATRE_ID != undefined && this.DRAMA_ID.length != 0) {
      this.filterQuery +=
        " AND THEATRE_ID ='" +
        this.THEATRE_ID +
        "' AND SHOW_ID ='" +
        this.DRAMA_ID +
        "' ";
      this.filterClass = 'filter-invisible';
      this.isFilterApplied = 'primary';
      this.loadingRecords = true;
      this.search(true);
    } else if (this.startValue != undefined && this.endValue != undefined) {
      this.filterQuery =
        " AND DATE( PAYMENT_DATE_TIME ) BETWEEN '" +
        this.startValue +
        "' AND '" +
        this.endValue +
        "'";
      this.filterClass = 'filter-invisible';
      this.isFilterApplied = 'primary';
      this.loadingRecords = true;
      this.search(true);
    } else if (this.THEATRE_ID != undefined) {
      this.filterQuery = " AND (THEATRE_ID = '" + this.THEATRE_ID + "')";
      this.filterClass = 'filter-invisible';
      this.isFilterApplied = 'primary';
      this.loadingRecords = true;
      this.search(true);
    } else if (this.DRAMA_ID.length != 0) {
      this.filterQuery += ' AND SHOW_ID in (' + this.DRAMA_ID + ')';
      this.filterClass = 'filter-invisible';
      this.isFilterApplied = 'primary';
      this.loadingRecords = true;
      this.search(true);
    }
  }

  clearFilter() {
    this.selectedDate = [];

    this.filterClass = 'filter-invisible';
    this.THEATRE_ID = null;
    this.DRAMA_ID = [];
    this.endValue = null;
    this.startValue = null;
    this.month = this.today;
    this.filterQuery = '';
    this.isFilterApplied = 'default';
    this.search();
  }

  sort(params: NzTableQueryParams): void {
    const { pageSize, pageIndex, sort } = params;
    const currentSort = sort.find((item) => item.value !== null);
    const sortField = (currentSort && currentSort.key) || 'id';
    const sortOrder = (currentSort && currentSort.value) || 'desc';
    console.log(currentSort);
    console.log('sortOrder :' + sortOrder);
    this.pageIndex = pageIndex;
    this.pageSize = pageSize;
    if (this.pageSize2 != pageSize) {
      this.pageSize2 = pageSize;
    }
    if (this.sortKey != sortField) {
      this.pageSize = pageSize;
    }
    this.sortKey = sortField;
    this.sortValue = sortOrder;
    this.search(true);
  }

  importInExcel() {
    this.search(true, true);
  }
  exportexcel(): void {
    var arry1 = [];
    var obj1: any = new Object();
    if (this.transactionExcelList.length > 0) {
      for (var i = 0; i < this.transactionExcelList.length; i++) {
        obj1['Theatre Name'] = this.transactionExcelList[i]['THEATRE_NAME'];
        obj1['Show Name'] = this.transactionExcelList[i]['SHOW_NAME'];
        obj1['Booking ID'] = this.transactionExcelList[i]['BOOKING_ID'];
        obj1['Seat Numbers'] = this.transactionExcelList[i]['SEAT_NUMBERS'];

        obj1['Payment Date Time'] =
          this.transactionExcelList[i]['PAYMENT_DATE_TIME'];
        obj1['Payment Gateway ID'] =
          this.transactionExcelList[i]['PAYMENT_GATEWAY_ID'];
        obj1['Total Tickets'] = this.transactionExcelList[i]['TOTAL_TICKETS'];
        obj1['Total Amount'] = this.transactionExcelList[i]['TOTAL_AMOUNT'];
        obj1['group laout name'] =
          this.transactionExcelList[i]['GROUP_LAYOUT_NAME'];

        arry1.push(Object.assign({}, obj1));
        if (i == this.transactionExcelList.length - 1) {
          this._exportService.exportExcel(
            arry1,
            'Booking Report"' +
              this.datePipe.transform(new Date(), 'yyyy-MM-dd')
          );
        }
      }
    } else {
      this.message.error('There Is No Data', '');
    }
  }

  DateChange(event: any) {
    this.startValue = this.datePipe.transform(event[0], 'yyyy-MM-dd');
    this.endValue = this.datePipe.transform(event[1], 'yyyy-MM-dd');
    console.log('this.startValue', this.startValue);
    console.log('this.endValue', this.endValue);
  }
}
