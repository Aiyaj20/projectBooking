import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NzTableQueryParams } from 'ng-zorro-antd/table';
import { ClientmasterService } from 'src/app/Services/clientmaster.service';
import { ExportService } from 'src/app/export.service';

@Component({
  selector: 'app-show-summary-report',
  templateUrl: './show-summary-report.component.html',
  styleUrls: ['./show-summary-report.component.css'],
})
export class ShowSummaryReportComponent implements OnInit {
  table: any = [];
  totalRecords: any;
  pageSize = 10;
  pageIndex = 1;
  loadingRecords = false;

  FilterApplied: any = 'default';
  filterClass: string = 'filter-invisible';
  searchText: any = '';
  today =
  new Date().getFullYear().toString() +
  '-' +
  (new Date().getMonth() + 1).toString() +
  '-' +
  new Date().getDate().toString();
  current = new Date();
  month = this.today;
  // filterQuery: string = '';
  sortKey: string = 'id';
  sortValue: string = 'desc';
  query: any;
  columns: string[][] = [
    ['THEATER_NAME', ' theater name'],
    ['DRAMA_NAME', 'drama name'],
    ['DATE', 'date'],
    ['TOTAL_SEATS', 'total seats'],
    ['RESERVED_SEATS', 'researved seats'],
    ['AVAILABLE_FOR_BOOKING', 'available for booking'],
    ['BOOKED_SEATS', 'booked seats'],   
    ['AVAILABLE_SEATS', 'available seats'],
    ['TOTAL_REVENUE', 'total revenue'],
  ];

  selectedDate: Date[] = [];
  endOpen = false;
  TheatreID: any;
  DataList: any;
  Master: any;
  showID: any;
  Spinning = false;
  data: any = [];
  dateFormat = 'dd/MM/yyyy';

  bookingsexcel: any[] = [];
  exportbook = [];
  filterQuery=''
  // filterQuery= "AND DATE(SHOW_DATE) = '"+ this.month+"'";
  constructor(
    public api: ClientmasterService,
    private message: NzNotificationService,
    private datePipe: DatePipe,
    private exportService: ExportService
  ) { }
  ngOnInit(): void {
    this.api.getTheatreMaster(0, 0, '', '', 'AND STATUS = 1').subscribe(
      (data) => {
        if (data['code'] == 200) {
          this.DataList = data['data'];
          console.log('Theater data:', this.DataList);
        }
      },
      (err) => {
        console.log(err);
      }
    );

    this.api.getdramaMaster(0, 0, '', '', 'AND STATUS = 1').subscribe(
      (data) => {
        if (data['code'] == 200) {
          this.Master = data['data'];
          console.log('Master data:', this.Master);
        }
      },
      (err) => {
        console.log(err);
      }
    );
    // this.selectedDate = new Date ()
    // this.selectedDate[0] = new Date();
    // this.selectedDate[1] = new Date();
    this.selectedDate[0] = new Date( );
    this.selectedDate[1] = new Date();
    this.DateChange(this.selectedDate);
    // this.startValue = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    // this.endValue = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.applyFilter()
  }

  keyup(event: any) {
    this.search();
  }

  KeypressEvent(reset: any) {
    const element = window.document.getElementById('button');
    if (element != null) element.focus();
    this.search();
  }

  showFilter() {
    if (this.filterClass === 'filter-visible')
      this.filterClass = 'filter-invisible';
    else this.filterClass = 'filter-visible';
  }

  sort(params: NzTableQueryParams): void {
    const { pageSize, pageIndex, sort } = params;
    const currentSort = sort.find((item) => item.value !== null);
    const sortField = (currentSort && currentSort.key) || 'id';
    const sortOrder = (currentSort && currentSort.value) || 'desc';
    console.log(currentSort);

    console.log('sortOrder :' + sortOrder);
    this.pageIndex = pageIndex;
    this.pageSize = pageSize;

    if (this.pageSize != pageSize) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
    }

    if (this.sortKey != sortField) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
    }

    this.sortKey = sortField;
    this.sortValue = sortOrder;
    this.search();
  }

  search(reset: boolean = false, exportInExcel: boolean = false) {
    if (reset) {
      this.pageIndex = 1;
      this.sortKey = 'id';
      this.sortValue = 'desc';
    }
    this.loadingRecords = true;
    var sort: string;
    try {
      sort = this.sortValue.startsWith('a') ? 'asc' : 'desc';
    } catch (error) {
      sort = '';
    }
    var likeQuery = '';
    console.log('search text:' + this.searchText);
    if (this.searchText != '') {
      likeQuery = ' AND(';
      this.columns.forEach((column) => {
        likeQuery += ' ' + column[0] + " like '%" + this.searchText + "%' OR";
      });
      likeQuery = likeQuery.substring(0, likeQuery.length - 2) + ')';
      console.log('likeQuery' + likeQuery);
    }
    var filter = '';
    if (likeQuery) filter = this.filterQuery + likeQuery;
    else filter = this.filterQuery;
    this.query = likeQuery;

    if (exportInExcel) {
      this.api
        .getShowSummaryReport(
          0,
          0,
          this.sortKey,
          sort,
          likeQuery + this.filterQuery
        )
        .subscribe(
          (data) => {
            if (data['code'] == 200) {
              this.loadingRecords = false;
              this.totalRecords = data['count'];
              this.exportbook = data['data'];
              console.log(this.table, 'booking details');
              this.DownloadExcelFile();
            } else {
              this.message.error('Something Went Wrong', '');
              this.loadingRecords = false;
            }
          },
          (err) => {
            console.log(err);
          }
        );
    } else {
      this.api
        .getShowSummaryReport(
          this.pageIndex,
          this.pageSize,
          this.sortKey,
          sort,
          likeQuery + this.filterQuery
        )
        .subscribe(
          (data) => {
            if (data['code'] == 200) {
              this.loadingRecords = false;
              this.totalRecords = data['count'];
              this.table = data['data'];
              // this.DownloadExcel()
            } else {
              this.message.error('Something Went Wrong', '');
              this.loadingRecords = false;
            }
          },
          (err) => {
            console.log(err);
          }
        );
    }
  }

  StartDate(open: boolean) {
    if (!open) {
      this.endOpen = true;
    }
  }
  startValue: any;
  endValue: any;
  DateChange(event: any) {
    // var startDate = this.datePipe.transform(this.startValue, 'yyyy-MM-dd');
    this.startValue = this.datePipe.transform(event[0], 'yyyy-MM-dd');
    this.endValue = this.datePipe.transform(event[1], 'yyyy-MM-dd');
    console.log('this.startValue', this.startValue);
    console.log('this.endValue', this.endValue);
    console.log('sdf', this.TheatreID);
    console.log('this.==', this.showID);
  }

  applyFilter() {
    // console.log(this.applyFilter);
    this.loadingRecords = true;
    var sort: string;
    try {
      sort = this.sortValue.startsWith('a') ? 'asc' : 'desc';
    } catch (error) {
      sort = '';
    }

    if (
      this.startValue != undefined &&
      this.startValue != null &&
      this.TheatreID != undefined &&
      this.showID != undefined &&
      (this.endOpen != undefined || this.endValue != null)
    ) {
      this.filterQuery =
        " AND ( DATE BETWEEN '" +
        this.startValue +
        "'AND'" +
        this.endValue +
        "') AND THEATRE_ID = '" +
        this.TheatreID +
        "'AND DRAMA_ID in (" +
        this.showID +
        ")";
      // this.startValue + "' AND '" +this.endValue +  "') ";
      this.filterClass = 'filter-invisible';
      this.FilterApplied = 'primary';
      this.search(true);
    } else if (
      this.startValue != undefined &&
      this.endValue != undefined &&
      this.TheatreID != undefined
    ) {
      this.filterQuery =
        " AND ( DATE BETWEEN '" +
        this.startValue +
        " ' AND '" +
        this.endValue +
        "' AND THEATRE_ID = ' " +
        this.TheatreID +
        " ')";
      this.filterClass = 'filter-invisible';
      this.FilterApplied = 'primary';
      this.search(true);
    } else if (
      this.startValue != undefined &&
      this.endValue != undefined &&
      this.showID != undefined
    ) {
      this.filterQuery =
        " AND ( DATE BETWEEN '" +
        this.startValue +
        "' AND '" +
        this.endValue +
        "') AND DRAMA_ID in (" +
        this.showID +
        ")";

      this.filterClass = 'filter-invisible';
      this.FilterApplied = 'primary';
      this.search(true);
    } else if (this.TheatreID != undefined && this.showID != undefined) {
      this.filterQuery +=
        " AND THEATRE_ID ='" +
        this.TheatreID +
        "' AND DRAMA_ID in (" +
        this.showID +
        ") ";
      this.filterClass = 'filter-invisible';
      this.FilterApplied = 'primary';
      this.search(true);
    } else if (this.startValue != undefined && this.endValue != undefined) {
      this.filterQuery =
        " AND DATE( CREATED_MODIFIED_DATE ) BETWEEN '" +
        this.startValue +
        "' AND '" +
        this.endValue +
        "' ";
      this.filterClass = 'filter-invisible';
      this.FilterApplied = 'primary';
      this.search(true);
    } else if (this.TheatreID != undefined) {
      this.filterQuery = " AND (THEATRE_ID = '" + this.TheatreID + "')";
      this.filterClass = 'filter-invisible';
      this.FilterApplied = 'primary';
      this.search(true);
    } else if (this.showID != undefined) {
      this.filterQuery += " AND DRAMA_ID in (" + this.showID + ")";
      this.filterClass = 'filter-invisible';
      this.FilterApplied = 'primary';
      this.search(true);
    }

    // this.api.getShowSummaryReport(this.pageIndex, this.pageSize, this.sortKey, sort, this.filterQuery)
    //   .subscribe(
    //     (data) => {
    //       if (data['code'] == 200) {
    //         this.loadingRecords = false;
    //         this.totalRecords = data['count'];
    //         this.table = data['data'];
    //       } else {
    //         this.message.error('Something Went Wrong', '');
    //         this.loadingRecords = false;
    //       }
    //     },
    //     (err) => {
    //       console.log(err);
    //     })
  }

  DownloadExcel(): void {
    this.search(true, true);
  }

  DownloadExcelFile(): void {
    const excelData = [];
    if (this.exportbook.length > 0) {
      for (let i = 0; i < this.exportbook.length; i++) {
        const obj1: any = {};
        obj1['City Name'] = this.exportbook[i]['CITY_NAME'];
        obj1['Theatre Name'] = this.exportbook[i]['THEATRE_NAME'];
        obj1['Show Name'] = this.exportbook[i]['DRAMA_NAME'];
        obj1['Show Date'] = this.exportbook[i]['GROUP_LAYOUT_NAME'];
        obj1['Transaction Count'] = this.exportbook[i]['TRASACTION_COUNT'];
        obj1['Total Amount'] = this.exportbook[i]['TOTAL_AMOUNT'];
        excelData.push(Object.assign({}, obj1));
        if (i == this.exportbook.length - 1) {
          this.exportService.exportExcel(
            excelData,
            'Category Wise Report"' +
            this.datePipe.transform(new Date(), 'yyyy-MM-dd')
          );
        }
      }
    } else {
      this.message.error("There Is No Data", "")
    }
  }

  clearFilter() {
    this.selectedDate = [];
    this.showID = null;
    this.TheatreID = null;
    this.filterQuery = '';
    this.startValue =null
    this.endValue =null
    this.filterClass = 'filter-invisible';
    this.FilterApplied = 'default';
    this.search();

    this.filterClass = 'filter-invisible';
  }
}
