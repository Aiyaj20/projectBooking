import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NzTableQueryParams } from 'ng-zorro-antd/table';
import { ClientmasterService } from 'src/app/Services/clientmaster.service';
import { ExportService } from 'src/app/export.service';

@Component({
  selector: 'app-show-summary-report',
  templateUrl: './show-summary-report.component.html',
  styleUrls: ['./show-summary-report.component.css'],
})
export class ShowSummaryReportComponent implements OnInit {
  table: any = [];
  totalRecords: any;
  pageSize = 10;
  pageIndex = 1;
  loadingRecords = false;

  isFilterApplied: any = 'default';
  filterClass: string = 'filter-invisible';
  searchText: any = '';
  today =
    new Date().getFullYear().toString() +
    '-' +
    (new Date().getMonth() + 1).toString() +
    '-1';

  current = new Date();
  month = this.today;
  // filterQuery: string = '';
  sortKey: string = 'id';
  sortValue: string = 'desc';
  query: any;
  columns: string[][] = [
    ['THEATRE_NAME', ' theater name'],
    ['SHOW_NAME', 'drama name'],
    ['SHOW_DATE', 'date'],
    ['TOTAL_SEATS', 'total seats'],
    ['BOOKED_SEATS', 'researved seats'],
    ['COLLECTED_AMOUNT', 'Collected Amount'],
  ];

  selectedDate: Date[] = [];
  endOpen = false;
  THEATRE_ID: any;
  DataList: any;
  Master: any;
  CityData: any;
  DRAMA_ID: any;
  CITY_ID: any;
  Spinning = false;
  data: any = [];
  dateFormat = 'dd/MM/yyyy';

  bookingsexcel: any[] = [];
  exportbook = [];
  filterQuery = '';
  // filterQuery= "AND DATE(SHOW_DATE) = '"+ this.month+"'";
  constructor(
    public api: ClientmasterService,
    private message: NzNotificationService,
    private datePipe: DatePipe,
    private exportService: ExportService
  ) {}
  ngOnInit(): void {
    var date = new Date();
    this.selectedDate[0] = new Date(date.getFullYear(), date.getMonth(), 1);
    this.selectedDate[1] = new Date(date.getFullYear(), date.getMonth() + 1, 0);

    this.api.getCityMaster(0, 0, '', '', 'AND STATUS = 1').subscribe(
      (data) => {
        if (data['code'] == 200) {
          this.CityData = data['data'];
          console.log('Theater data:', this.CityData);
        }
      },
      (err) => {
        console.log(err);
      }
    );
    this.applyFilter();
  }

  gettheatername(cityid: number) {
    this.getdramas(cityid);
    this.CITY_ID = cityid;
    var filter = '';
    if (cityid == 0) {
    } else {
      filter = ' AND CITY_ID=' + cityid;
    }
    this.api
      .getTheatreMaster(0, 0, '', '', 'AND STATUS = 1 ' + filter)
      .subscribe(
        (data) => {
          if (data['code'] == 200) {
            this.DataList = data['data'];
          } else {
            this.message.error("Can't Load Theater Name", '');
          }
        },
        (err) => {
          console.log(err);
        }
      );
  }

  getdramas(city: any) {
    var filter = '';

    if (city == 0) {
    } else {
      filter = ' AND CITY_ID=' + city;
    }

    this.api

      .getdramaMaster(0, 0, 'ID', 'ASC', 'AND STATUS = 1 ' + filter)

      .subscribe(
        (data) => {
          if (data['code'] == 200) {
            this.Master = data['data'];
          } else {
            this.message.error("Can't Load Drama Name", '');
          }
        },

        (err) => {
          console.log(err);
        }
      );
  }

  keyup(event: any) {
    this.search();
  }

  KeypressEvent(reset: any) {
    const element = window.document.getElementById('button');
    if (element != null) element.focus();
    this.search();
  }

  showFilter() {
    if (this.filterClass === 'filter-visible')
      this.filterClass = 'filter-invisible';
    else this.filterClass = 'filter-visible';
  }

  sort(params: NzTableQueryParams): void {
    const { pageSize, pageIndex, sort } = params;
    const currentSort = sort.find((item) => item.value !== null);
    const sortField = (currentSort && currentSort.key) || 'id';
    const sortOrder = (currentSort && currentSort.value) || 'desc';
    console.log(currentSort);

    console.log('sortOrder :' + sortOrder);
    this.pageIndex = pageIndex;
    this.pageSize = pageSize;

    if (this.pageSize != pageSize) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
    }

    if (this.sortKey != sortField) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
    }

    this.sortKey = sortField;
    this.sortValue = sortOrder;
    this.search();
  }

  search(reset: boolean = false, exportInExcel: boolean = false) {
    if (reset) {
      this.pageIndex = 1;
      this.sortKey = 'id';
      this.sortValue = 'desc';
    }
    this.loadingRecords = true;
    var sort: string;
    try {
      sort = this.sortValue.startsWith('a') ? 'asc' : 'desc';
    } catch (error) {
      sort = '';
    }
    var likeQuery = '';
    console.log('search text:' + this.searchText);
    if (this.searchText != '') {
      likeQuery = ' AND(';
      this.columns.forEach((column) => {
        likeQuery += ' ' + column[0] + " like '%" + this.searchText + "%' OR";
      });
      likeQuery = likeQuery.substring(0, likeQuery.length - 2) + ')';
      console.log('likeQuery' + likeQuery);
    }
    var filter = '';
    if (likeQuery) filter = this.filterQuery + likeQuery;
    else filter = this.filterQuery;
    this.query = likeQuery;

    if (exportInExcel) {
      this.api
        .getShowSummaryReport(
          0,
          0,
          this.sortKey,
          sort,
          likeQuery + this.filterQuery
        )
        .subscribe(
          (data) => {
            if (data['code'] == 200) {
              this.loadingRecords = false;
              this.totalRecords = data['count'];
              this.exportbook = data['data'];
              console.log(this.table, 'booking details');
              this.DownloadExcelFile();
            } else {
              this.message.error('Something Went Wrong', '');
              this.loadingRecords = false;
            }
          },
          (err) => {
            console.log(err);
          }
        );
    } else {
      this.api
        .getShowSummaryReport(
          this.pageIndex,
          this.pageSize,
          this.sortKey,
          sort,
          likeQuery + this.filterQuery
        )
        .subscribe(
          (data) => {
            if (data['code'] == 200) {
              this.loadingRecords = false;
              this.totalRecords = data['count'];
              this.table = data['data'];
              // this.DownloadExcel()
            } else {
              this.message.error('Something Went Wrong', '');
              this.loadingRecords = false;
            }
          },
          (err) => {
            console.log(err);
          }
        );
    }
  }

  StartDate(open: boolean) {
    if (!open) {
      this.endOpen = true;
    }
  }
  startValue: any;
  endValue: any;
  applyFilter() {
    this.filterQuery = '';
    if (this.selectedDate != undefined && this.selectedDate != null) {
      this.startValue = this.datePipe.transform(
        this.selectedDate[0],
        'yyyy-MM-dd'
      );
      this.endValue = this.datePipe.transform(
        this.selectedDate[1],
        'yyyy-MM-dd'
      );

      this.filterQuery =
        " AND (SHOW_DATE BETWEEN '" +
        this.startValue +
        "' AND '" +
        this.endValue +
        "')";
    }
    if (
      this.THEATRE_ID != undefined &&
      this.THEATRE_ID != null &&
      this.THEATRE_ID != 0
    ) {
      this.filterQuery += " AND (THEATRE_ID = '" + this.THEATRE_ID + "')";
    }
    if (
      this.CITY_ID != undefined &&
      this.CITY_ID != null &&
      this.CITY_ID != 0
    ) {
      this.filterQuery += " AND (CITY_ID = '" + this.CITY_ID + "')";
    }
    if (
      this.DRAMA_ID != undefined &&
      this.DRAMA_ID != null &&
      this.DRAMA_ID.length > 0
    ) {
      this.filterQuery += ' AND DRAMA_ID in (' + this.DRAMA_ID + ')';
    }

    this.filterClass = 'filter-invisible';
    this.isFilterApplied = 'primary';
    this.loadingRecords = true;
    this.search(true);
  }

  DownloadExcel(): void {
    this.search(true, true);
  }

  DownloadExcelFile(): void {
    const excelData = [];
    if (this.exportbook.length > 0) {
      for (let i = 0; i < this.exportbook.length; i++) {
        const obj1: any = {};
        obj1['City Name'] = this.exportbook[i]['CITY_NAME'];
        obj1['Theatre Name'] = this.exportbook[i]['THEATRE_NAME'];
        obj1['Show Name'] = this.exportbook[i]['DRAMA_NAME'];
        obj1['Show Date'] = this.exportbook[i]['GROUP_LAYOUT_NAME'];
        obj1['Transaction Count'] = this.exportbook[i]['TRASACTION_COUNT'];
        obj1['Total Amount'] = this.exportbook[i]['TOTAL_AMOUNT'];
        excelData.push(Object.assign({}, obj1));
        if (i == this.exportbook.length - 1) {
          this.exportService.exportExcel(
            excelData,
            'Category Wise Report"' +
              this.datePipe.transform(new Date(), 'yyyy-MM-dd')
          );
        }
      }
    } else {
      this.message.error('There Is No Data', '');
    }
  }

  // clearFilter() {
  //   this.selectedDate = [];
  //   this.showID = null;
  //   this.TheatreID = null;
  //   this.filterQuery = '';
  //   this.startValue =null
  //   this.endValue =null
  //   this.filterClass = 'filter-invisible';
  //   this.isFilterApplied = 'default';
  //   this.search();

  //   this.filterClass = 'filter-invisible';
  // }

  clearFilter() {
    this.filterClass = 'filter-invisible';
    this.THEATRE_ID = 0;
    this.CITY_ID = 0;
    this.DRAMA_ID = [];
    var date = new Date();
    this.selectedDate[0] = new Date(date.getFullYear(), date.getMonth(), 1);
    this.selectedDate[1] = new Date(date.getFullYear(), date.getMonth() + 1, 0);

    this.endValue = null;
    this.startValue = null;
    this.filterQuery = '';
    this.isFilterApplied = 'default';
    this.search(true);
  }
}
