import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NzTableQueryParams } from 'ng-zorro-antd/table';
import { ClientmasterService } from 'src/app/Services/clientmaster.service';
import { ExportService } from 'src/app/export.service';
// import { ExportService } from '../export.service';

@Component({
  selector: 'app-categogy-wise-report',
  templateUrl: './categogy-wise-report.component.html',
  styleUrls: ['./categogy-wise-report.component.css']
})
export class CategogyWiseReportComponent implements OnInit {

  dataList1: any[] = [];

  isFilterApplied: any = 'default';
  filterQuery: string = '';
  isOk: boolean = false;
  totalRecords: any;
  pageSize = 10;
  pageIndex = 1;
  sortKey: string = 'id';
  sortValue: string = 'desc';
  searchText: any = '';
  loadingRecords = true;
  filterClass: string = 'filter-invisible';
  startValue: any;
  endValue: any;
  today2 = new Date();
  isSpinning = false;
  endOpen = false;
  startOpen = false;
  dates: any = [];
  bookingdetails: any = [];
  query: any;
  pageSize2 = 10
  today =
    new Date().getFullYear().toString() +
    '-' +
    (new Date().getMonth() + 1).toString() +
    '-' +
    new Date().getDate().toString();

  current = new Date();
  month = this.today;
  type: any;
  exportbook = []
  bookingsexcel: any[] = [];
  SHOW_DATE: any
  THEATRE_ID: any
  DRAMA_ID: any
  LAYOUT_ID: any
  layout: any = []

  columns: string[][] = [
    ['CITY_NAME', 'CITY_NAME'],
    ['THEATRE_NAME', 'THEATRE_NAME'],
    ['DRAMA_NAME', 'DRAMA_NAME'],
    ['GROUP_LAYOUT_NAME', 'GROUP_LAYOUT_NAME'],
  ];
  constructor(
    public api: ClientmasterService,
    private message: NzNotificationService,
    private datePipe: DatePipe,
    private _exportService: ExportService
  ) { }
  show: any = []
  category: any
  ngOnInit(): void {
    this.gettheatername()
    this.getshowname()
    this.getGroupLayoutName()
  }


  getGroupLayoutName() {
    this.api.getSeatLayoutMaster(0, 0, '', '', ' AND STATUS = 1').subscribe(
      (data) => {
        if (data['code'] == 200) {
          this.layout = data['data']
        }
        else {
          this.message.error("Can't Load Group Layout Name", '');
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }
  keyup(event: any) {
    this.search();
  }

  onKeypressEvent(reset: any) {
    const element = window.document.getElementById('button');
    if (element != null) element.focus();
    this.search();
  }

  NAME: any
  ID: any
  theater: any = []
  gettheatername() {
    this.api.getTheatreMaster(0, 0, '', '', 'AND STATUS = 1').subscribe(
      (data) => {
        if (data['code'] == 200) {
          this.theater = data['data']
        }
        else {
          this.message.error("Can't Load Theater Name", '');
        }
      },
      (err) => {
        console.log(err);
      }
    );

  }




  getshowname() {
    this.api.getdramaMaster(0, 0, '', '', 'AND STATUS = 1').subscribe(
      (data) => {
        if (data['code'] == 200) {
          this.show = data['data']
        }
        else {
          this.message.error("Can't Load Show Name", '');
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  search(reset: boolean = false, exportInExcel: boolean = false) {
    if (reset) {

    }
    this.loadingRecords = true;
    var sort: string;
    try {
      sort = this.sortValue.startsWith('a') ? 'asc' : 'desc';
    } catch (error) {
      sort = '';
    }
    var likeQuery = '';
    console.log('search text:' + this.searchText);
    if (this.searchText != '') {
      likeQuery = ' AND(';
      this.columns.forEach((column) => {
        likeQuery += ' ' + column[0] + " like '%" + this.searchText + "%' OR";
      });
      likeQuery = likeQuery.substring(0, likeQuery.length - 2) + ')';
      console.log('likeQuery' + likeQuery);
    }
    var filter = '';
    if (likeQuery) filter = this.filterQuery + likeQuery;
    else filter = this.filterQuery;
    this.query = likeQuery
    if (exportInExcel == false) {
      this.api.getcategory(this.pageIndex, this.pageSize, this.sortKey, sort, likeQuery + this.filterQuery).subscribe(
        (data) => {
          if (data['code'] == 200) {
            this.loadingRecords = false;
            this.totalRecords = data['count'];
            this.bookingdetails = data['data'];
            console.log(this.bookingdetails, 'booking details')
          } else {
            this.message.error('Something Went Wrong', '');
            this.loadingRecords = false;
          }
        },
        (err) => {
          console.log(err);
        }
      );
    }
    else {
      this.api.getcategory(0, 0, this.sortKey, sort, likeQuery + this.filterQuery,).subscribe(data => {
        if (data['code'] == 200) {
          this.loadingRecords = false;
          this.exportbook = data['data'];
          this.exportexcel();
        }
      },
        err => {
          if (err['ok'] == false)
            this.message.error("Server Not Found", "");
        });
    }
  }
  showFilter() {
    if (this.filterClass === 'filter-visible')
      this.filterClass = 'filter-invisible';
    else this.filterClass = 'filter-visible';
  }







  value1: any
  value2: any
  
  applyFilter() {
    if (this.SHOW_DATE != undefined) {
      this.value1 = this.datePipe.transform(this.SHOW_DATE[0], "yyyy-MM-dd")
      this.value2 = this.datePipe.transform(this.SHOW_DATE[1], "yyyy-MM-dd")
    }

    this.filterQuery = ""
    console.log(this.filterQuery + 'filterquery');


    if (this.value1 != undefined && this.value2 != undefined && this.THEATRE_ID != undefined &&
      this.DRAMA_ID != undefined && this.LAYOUT_ID != undefined) {
      this.filterQuery += " AND ( SHOW_DATE BETWEEN '" + this.value1 + "' AND '" + this.value2 +
        "') AND THEATRE_ID ='" + this.THEATRE_ID + "' AND DRAMA_ID = '" + this.DRAMA_ID
        + "' AND LAYOUT_ID = '" + this.LAYOUT_ID + "' ";
        this.isFilterApplied = 'primary'
      this.filterClass = "filter-invisible";
      this.search(true)
    }
    else if (this.value1 != undefined && this.value2 != undefined && this.THEATRE_ID != undefined
      && this.DRAMA_ID != undefined) {
      this.filterQuery += " AND ( SHOW_DATE BETWEEN '" + this.value1 + "' AND '" +
        this.value2 + "') AND THEATRE_ID ='" + this.THEATRE_ID + "' AND DRAMA_ID ='" + this.DRAMA_ID + "'";
        this.isFilterApplied = 'primary'
      this.filterClass = "filter-invisible";
      this.search(true)
    }
    else if (this.THEATRE_ID != undefined && this.DRAMA_ID != undefined && this.LAYOUT_ID != undefined) {
      this.filterQuery += " AND THEATRE_ID = '" + this.THEATRE_ID + "' AND DRAMA_ID ='" + this.DRAMA_ID
        + "' AND LAYOUT_ID = '" + this.LAYOUT_ID + "'";
        this.isFilterApplied = 'primary'
      this.filterClass = "filter-invisible";
      this.search(true)
    }
    else if (this.value1 != undefined && this.value2 != undefined && this.THEATRE_ID != undefined) {
      this.filterQuery += " AND ( SHOW_DATE BETWEEN '" + this.value1 + "' AND '" +
        this.value2 + "') AND THEATRE_ID ='" + this.THEATRE_ID + "'";
        this.isFilterApplied = 'primary'
      this.filterClass = "filter-invisible";
      this.search(true)
    }
    else if (this.value1 != undefined && this.value2 != undefined && this.DRAMA_ID != undefined) {
      this.filterQuery += " AND ( SHOW_DATE BETWEEN '" + this.value1 + "' AND '" +
        this.value2 + "') AND DRAMA_ID ='" + this.DRAMA_ID + "'";
        this.isFilterApplied = 'primary'
        this.filterClass = "filter-invisible";
      this.search(true)
    }
    else if (this.value1 != undefined && this.value2 != undefined && this.LAYOUT_ID != undefined) {
      this.filterQuery += " AND ( SHOW_DATE BETWEEN '" + this.value1 + "' AND '" + this.value2 +
        "') AND LAYOUT_ID ='" + this.LAYOUT_ID + "'";
      this.isFilterApplied = 'primary'
      this.filterClass = "filter-invisible";
      this.search(true)
    }
    else if (this.THEATRE_ID != undefined && this.DRAMA_ID != undefined) {
      this.filterQuery += " AND THEATRE_ID ='" + this.THEATRE_ID + "' AND DRAMA_ID ='" + this.DRAMA_ID + "' ";
      this.isFilterApplied = 'primary'
      this.filterClass = "filter-invisible";
      this.search(true)
    }
    else if (this.THEATRE_ID != undefined && this.LAYOUT_ID != undefined) {
      this.filterQuery += " AND THEATRE_ID ='" + this.THEATRE_ID + "' AND LAYOUT_ID ='" + this.LAYOUT_ID + "' ";
      this.isFilterApplied = 'primary'
      this.filterClass = "filter-invisible";
      this.search(true)
    }
    else if (this.DRAMA_ID != undefined && this.LAYOUT_ID != undefined) {
      this.filterQuery += " AND DRAMA_ID ='" + this.DRAMA_ID + "' AND LAYOUT_ID ='" + this.LAYOUT_ID + "' ";
      this.isFilterApplied = 'primary'
      this.filterClass = "filter-invisible";
      this.search(true)
    }
    else if (this.value1 != undefined && this.value2 != undefined) {
      this.filterQuery += " AND ( SHOW_DATE BETWEEN '" + this.value1 + "' AND '" + this.value2 + "')";
      this.isFilterApplied = 'primary'
      this.filterClass = "filter-invisible";
      this.search(true)
    }
    else if (this.THEATRE_ID != undefined) {
      this.filterQuery += " AND THEATRE_ID = '" + this.THEATRE_ID + "'";
      this.isFilterApplied = 'primary'
      this.filterClass = "filter-invisible";
      this.search(true)
    }
    else if (this.DRAMA_ID != undefined) {
      this.filterQuery += " AND DRAMA_ID = '" + this.DRAMA_ID + "'";
      this.isFilterApplied = 'primary'
      this.filterClass = "filter-invisible";
      this.search(true)
    }
    else if (this.LAYOUT_ID != undefined) {
      this.filterQuery += " AND LAYOUT_ID = '" + this.LAYOUT_ID + "'";
      this.isFilterApplied = 'primary'
      this.filterClass = "filter-invisible";
      this.search(true)
    }
    else if (this.value1 == undefined && this.value2 == undefined && this.THEATRE_ID == undefined &&
      this.DRAMA_ID == undefined && this.LAYOUT_ID == undefined) {
      this.message.error('Please Select filter field to apply filter', '')
    }
  }


  clearFilter() {
    this.filterClass = 'filter-invisible';
    this.SHOW_DATE = []
    this.value1 = [];
    this.value2 = [];
    this.THEATRE_ID = null
    this.DRAMA_ID = null
    this.LAYOUT_ID = null
    this.filterQuery = '';
    this.isFilterApplied = 'default';
    this.search();
  }

  sort(params: NzTableQueryParams): void {
    const { pageSize, pageIndex, sort } = params;
    const currentSort = sort.find((item) => item.value !== null);
    const sortField = (currentSort && currentSort.key) || 'id';
    const sortOrder = (currentSort && currentSort.value) || 'desc';
    console.log(currentSort);

    console.log('sortOrder :' + sortOrder);
    this.pageIndex = pageIndex;
    this.pageSize = pageSize;

    if (this.pageSize2 != pageSize) {
      this.pageSize2 = pageSize;
    }

    if (this.sortKey != sortField) {
      this.pageSize = pageSize;
    }

    this.sortKey = sortField;
    this.sortValue = sortOrder;
    this.search(true);
  }




  importInExcel() {
    this.search(true, true);
  }
  exportexcel(): void {
    var arry1 = [];
    var obj1: any = new Object();
    
    if (this.exportbook.length > 0) {
      for (var i = 0; i < this.exportbook.length; i++) {
        obj1['City Name'] = this.exportbook[i]['CITY_NAME'];
        obj1['Theatre Name'] = this.exportbook[i]['THEATRE_NAME'];
        obj1['Drama Name'] = this.exportbook[i]['DRAMA_NAME'];
        obj1['Group Layout Name'] = this.exportbook[i]['GROUP_LAYOUT_NAME'];
        obj1['Show Time'] = this.exportbook[i]['SHOW_TIME'];
        obj1['Total Seats'] = this.exportbook[i]['TOTAL_SEATS'];
        obj1['Booked Seats'] = this.exportbook[i]['BOOKED_SEATS'];
        obj1['Available For Booking'] = this.exportbook[i]['AVAILABLE_FOR_BOOKING'];
        obj1['Available Seats'] = this.exportbook[i]['AVAILABLE_SEATS'];
        obj1['Reserved Seats'] = this.exportbook[i]['RESERVED_SEATS'];
        obj1['Amount'] = this.exportbook[i]['AMOUNT'];
        arry1.push(Object.assign({}, obj1));
        if (i == this.exportbook.length - 1) {
          this._exportService.exportExcel(arry1, 'Category Wise Report"' + this.datePipe.transform(new Date(), 'yyyy-MM-dd'));
        }
      }
    }
    else{
      this.message.error("There Is No Data","")
    }
  }



}
