export const appkeys = {
  gmUrl: 'https://gm.tecpool.in:8078/',

  // baseUrl: 'http://aptefoods.uvtechsoft.com:9830/',
  // url: 'http://aptefoods.uvtechsoft.com:9830/api/',
  // imgUrl: 'http://aptefoods.uvtechsoft.com:9830/api/upload/',
  // retriveimgUrl: 'http://aptefoods.uvtechsoft.com:9830/static/',



  // Testing
  // baseUrl: 'http://dramabookings.uvtechsoft.com:7896/',
  // url: 'http://dramabookings.uvtechsoft.com:7896/api/',
  // url1: 'http://dramabookings.uvtechsoft.com:7896/',
  // imgUrl: 'http://dramabookings.uvtechsoft.com:7896/upload/',
  // retriveimgUrl: 'http://dramabookings.uvtechsoft.com:7896/static/',


  //local

  baseUrl: 'https://6c6e-2405-201-1011-1028-c9e6-b7d-83fa-84bf.in.ngrok.io/',
  url: 'https://6c6e-2405-201-1011-1028-c9e6-b7d-83fa-84bf.in.ngrok.io/api/',
  url1: 'https://6c6e-2405-201-1011-1028-c9e6-b7d-83fa-84bf.in.ngrok.io/',
  imgUrl: 'https://6c6e-2405-201-1011-1028-c9e6-b7d-83fa-84bf.in.ngrok.io/upload/',
  retriveimgUrl: 'https://6c6e-2405-201-1011-1028-c9e6-b7d-83fa-84bf.in.ngrok.io/static/',

  // baseUrl: 'http://192.168.29.192:4470/',
  // url: 'http://192.168.29.192:4470/api/',
  // imgUrl: 'http://192.168.29.192:4470/api/upload/',
  // retriveimgUrl: 'http://192.168.29.192:4470/static/',

  // baseUrl: 'http://192.168.29.195:4544/',
  // url: 'http://192.168.29.195:4544/api/',
  // imgUrl: 'http://192.168.29.195:4544/api/upload/',
  // retriveimgUrl: 'http://192.168.29.195:4544/static/',
};
