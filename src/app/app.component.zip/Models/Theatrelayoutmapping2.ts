export class Theatrelayoutmapping2 {
  ID: number = 0;

  THEATRE_LAYOUT_MAPPING_ID: number = 0;
  ROW_NAME: string = '';
  START_SEAT_NUMBER: number = 0;
  END_SEAT_NUMBER: number = 0;
  IS_AVAILABLE_FOR_BOOKING: boolean = true;
  SEQUENCE_NUMBER: number = 0;
}
