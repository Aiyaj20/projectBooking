export class Theatrelayoutmapping {
    ID:number=0;
    THEATRE_ID:number=0;
    LAYOUT_ID:number=0;
    DEFAULT_RATE:number=0;
   
    // SEQUENCE_NO:number=0;
    // IS_ACTIVE:boolean=true;
}