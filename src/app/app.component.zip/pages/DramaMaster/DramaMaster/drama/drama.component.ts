import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NzTableQueryParams } from 'ng-zorro-antd/table';
import { DramaMAsterr } from 'src/app/Models/daramamaster';
import { ClientmasterService } from 'src/app/Services/clientmaster.service';
import { differenceInCalendarDays } from 'date-fns';
@Component({
  selector: 'app-drama',
  templateUrl: './drama.component.html',
  styleUrls: ['./drama.component.css'],
})
export class DramaComponent implements OnInit {
  isFilterApplied: any = 'default';
  drawerVisible: boolean = false;
  drawerTitle!: string;
  drawerData: DramaMAsterr = new DramaMAsterr();
  formTitle = 'Drama List';
  dataList = [];
  loadingRecords = false;
  totalRecords = 1;
  pageIndex = 1;
  pageSize = 10;
  isOk: boolean = false;
  sortValue: string = 'desc';
  sortKey: string = 'id';
  searchText: string = '';
  filterQuery: string = '';
  value1: any;
  value2: any;
  isSpinning = false;
  listOfData: DramaMAsterr[] = [];
  listOfData1: any[] = [];
  current = new Date();
  startValue: any;
  endValue: any;
  selectedDate: Date[] = [];
  dates: any = [];

  filterClass: any = 'filter-invisible';
  // isSpinning=false;
  // isFilterApplied:any='default'
  today2 = new Date();
  today =
    new Date().getFullYear().toString() +
    '-' +
    (new Date().getMonth() + 1).toString() +
    '-' +
    new Date().getDate().toString();
  // current = new Date();
  month = this.today;
  type: any;
  CITY_ID = [];

  // dataList:any[] = [];
  dataList1: any[] = [];
  endOpen = false;
  startOpen = false;
  FROM_DATE: any;
  TO_DATE: any;
  list: any = [];
  DramaMAsterr: any = [];
  Dramalistexcel: any = [];

  columns: string[][] = [
    ['CITY_NAME', ' City Name'],
    ['NAME', 'Drama Name'],
    ['CAST_NAMES', 'Cast Names'],
    ['DESCRIPTION', 'Description'],
    ['FROM_DATE', 'From Date'],
    ['TO_DATE', 'To Date'],
    ['SEQUENCE_NUMBER', 'Sequence No'],
    ['STATUS', 'Status'],
  ];
  imgUrl: any;
  // filterClass: string = 'filter-invisible';
  constructor(
    private api: ClientmasterService,
    private datePipe: DatePipe,
    private message: NzNotificationService
  ) {}

  ngOnInit(): void {
    this.changeDate(this.selectedDate);
  }

  keyup(event: any) {
    this.search();
  }

  search(reset: boolean = false) {
    if (reset) {
      this.pageIndex = 1;
      this.sortKey = 'id';
      this.sortValue = 'desc';
    }
    this.loadingRecords = true;
    var sort: string;
    try {
      sort = this.sortValue.startsWith('a') ? 'asc' : 'desc';
    } catch (error) {
      sort = '';
    }
    var likeQuery = '';
    console.log('search text:' + this.searchText);
    if (this.searchText != '') {
      likeQuery = ' AND';
      this.columns.forEach((column) => {
        likeQuery += ' ' + column[0] + " like '%" + this.searchText + "%' OR";
      });
      likeQuery = likeQuery.substring(0, likeQuery.length - 2);
      console.log('likeQuery' + likeQuery);
    }
    this.api
      .getdramaMaster(
        this.pageIndex,
        this.pageSize,
        this.sortKey,
        sort,
        likeQuery + this.filterQuery
      )
      .subscribe(
        (data) => {
          if (data['code'] == 200) {
            this.loadingRecords = false;
            this.totalRecords = data['count'];
            this.dataList = data['data'];
          
            // if(this.totalRecords==0){
            //   data.SEQUENCE_NO=1;
            // }
          } else {
            this.message.error('Something Went Wrong', '');
            this.loadingRecords = false;
          }
        },
        (err) => {
          console.log(err);
        }
      );
      this.api
      .getdramaMaster(
        this.pageIndex,
        this.pageSize,
        this.sortKey,
        sort,
        likeQuery + this.filterQuery
      )
      .subscribe(
        (data) => {
          if (data['code'] == 200) {
            this.loadingRecords = false;
            this.totalRecords = data['count'];
            this.listOfData1 = data['data'];

          }
        },
        (err) => {
          console.log(err);
        }
      );
  }

  //Drawer Methods
  get closeCallback() {
    return this.drawerClose.bind(this);
  }
  add(): void {
    this.drawerTitle = 'Add New Drama';
    this.drawerData = new DramaMAsterr();
    this.api.getdramaMaster(1, 1, 'SEQUENCE_NUMBER', 'desc', '').subscribe(
      (data) => {
        if (data['count'] == 0) {
          this.drawerData.SEQUENCE_NUMBER = 1;
        } else {
          this.drawerData.SEQUENCE_NUMBER =
            data['data'][0]['SEQUENCE_NUMBER'] + 1;
        }
      },
      (err) => {
        console.log(err);
      }
    );
    this.drawerVisible = true;
  }

  CAST_NAMES: any;
  height: any;
  width: any;

  edit(data: DramaMAsterr): void {
    this.drawerTitle = 'Update Drama Details';
    this.drawerData = Object.assign({}, data);
    this.drawerVisible = true;

    if (this.drawerData.CAST_NAMES == '') {
      this.drawerData.CAST_NAMES = [];
    } else {
      this.drawerData.CAST_NAMES = this.drawerData.CAST_NAMES.split(',');
    }

    // this.api.getdramaMaster(0, 0, '', 'asc', '').subscribe(data => {
    //   this.height = data['data'][0]['IMAGE_HEIGHT'];
    //   this.width = data['data'][0]['IMAGE_WIDTH'];
    // }, err => {
    //   console.log(err);
    //   // this.isSpinning = false;
    // });
  }
  drawerClose(): void {
    this.search();
    this.drawerVisible = false;
  }

  sort(params: NzTableQueryParams) {
    const { pageSize, pageIndex, sort } = params;
    const currentSort = sort.find((item) => item.value !== null);
    const sortField = (currentSort && currentSort.key) || 'id';
    const sortOrder = (currentSort && currentSort.value) || 'desc';
    this.loadingRecords = true;
    console.log(currentSort);

    console.log('sortOrder :' + sortOrder);
    this.pageIndex = pageIndex;
    this.pageSize = pageSize;

    if (this.pageSize != pageSize) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
    }

    if (this.sortKey != sortField) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
    }

    this.sortKey = sortField;
    this.sortValue = sortOrder;
    this.search();
  }
  getTimeIn12Hour(time: any) {
    return this.datePipe.transform(new Date(), 'yyyy-MM-dd' + ' ' + time);
  }

  changeDate(value: any) {
    this.value1 = this.datePipe.transform(value[0], 'yyyy-MM-dd');
    this.value2 = this.datePipe.transform(value[1], 'yyyy-MM-dd');
  }
  applyFilter() {
    console.log(this.FROM_DATE + 'sssssssss');
    console.log(this.TO_DATE + 'sssssssss');

    this.loadingRecords = true;
    var sort: string;
    try {
      sort = this.sortValue.startsWith('a') ? 'asc' : 'desc';
    } catch (error) {
      sort = '';
    }
    this.FROM_DATE = this.datePipe.transform(this.FROM_DATE, 'yyyy-MM-dd');
    this.TO_DATE = this.datePipe.transform(this.TO_DATE, 'yyyy-MM-dd');

    if (this.FROM_DATE != undefined && this.TO_DATE != undefined) {
      ////////////////////////////////////////////////////////////////
      this.isFilterApplied = 'primary';
      // this.filterQuery =
      //   " AND FROM_DATE between '" +
      //   this.FROM_DATE +
      //   "' AND '"
      //   +
      //   this.TO_DATE +
      //   "'" +" AND TO_DATE between '" +
      //   this.FROM_DATE +
      //   "' AND '" +
      //   this.TO_DATE +
      //   "'";

      this.filterQuery =
        " AND FROM_DATE between '" +
        this.FROM_DATE +
        ':00:00:00' +
        "' AND '" +
        this.TO_DATE +
        ':23:59:59' +
        "' " +
        "OR  TO_DATE between '" +
        this.FROM_DATE +
        ':00:00:00' +
        "' AND '" +
        this.TO_DATE +
        ':23:59:59' +
        "' ";

      //   " AND CITY_ID=" +
      //   this.type ;
      // this.filterQuery=
      // " AND FROM_DATE=" + this.FROM_DATE+" between TO_DATE=" + this.TO_DATE
      this.filterClass = 'filter-invisible';
    }

    // else if (
    //   this.FROM_DATE != undefined &&
    //   this.TO_DATE != undefined
    // ) {
    //   this.isFilterApplied='primary'
    //   this.filterQuery =
    //     " AND DATE between '" +
    //     this.FROM_DATE +
    //     "' AND '" +
    //     this.TO_DATE +
    //     "'";
    // this.filterClass='filter-invisible';
    // }
    else if (
      this.type != undefined &&
      this.FROM_DATE == undefined &&
      this.TO_DATE == undefined
    ) {
      // this.filterQuery = 'AND CITY_ID='+ "" + this.type;
      this.filterClass = 'filter-invisible';
    } else if (this.FROM_DATE == undefined && this.TO_DATE != undefined) {
      this.message.error('', 'Please Select Start Date');
    } else if (this.TO_DATE == undefined && this.FROM_DATE != undefined) {
      this.message.error('', 'Please Select End Date');
    } else if (
      this.FROM_DATE != undefined &&
      this.type != undefined &&
      this.TO_DATE == undefined
    ) {
      this.message.error('', 'Please Select End Date');
    } else if (
      this.TO_DATE != undefined &&
      this.type != undefined &&
      this.FROM_DATE == undefined
    ) {
      this.message.error('', 'Please Select Start Date');
    } else {
      this.message.error('', 'Please Selects Date');
    }
    ///local
    this.api
      .getdramaMaster(
        this.pageIndex,
        this.pageSize,
        this.sortKey,
        sort,
        this.filterQuery
      )
      .subscribe(
        (data) => {
          this.loadingRecords = false;
          this.dataList = data['data'];
          this.totalRecords = data['count'];
          this.DramaMAsterr = data['data'];
          this.listOfData1 = data['data'];
          console.log(this.dataList);
        },
        (err) => {
          console.log(err);
        }
      );
    // this.filterClass='filter-invisible';
  }
  clearFilter() {
    this.filterClass = 'filter-invisible';
    this.FROM_DATE = null;
    this.TO_DATE = null;
    this.selectedDate = [];

    this.isFilterApplied = 'default';
    this.filterQuery = '';

    this.listOfData = [];
    this.search();
  }

  showFilter() {
    if (this.filterClass === 'filter-visible')
      this.filterClass = 'filter-invisible';
    else this.filterClass = 'filter-visible';
  }

  disabledDate = (selected: Date): boolean =>
    // Can not select days before today and today
    differenceInCalendarDays(selected, this.current) > 0;

  moduleStartDateHandle(open: boolean) {
    if (!open) {
      this.endOpen = true;
    }
  }

  startDateChange() {
    var startDate = this.datePipe.transform(this.FROM_DATE, 'yyyy-MM-dd');
    var endDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');

    console.log(this.getDaysArray(startDate, endDate));
    console.log(this.dates);
  }

  getDaysArray(start: any, end: any) {
    for (
      var arr = [], dt = new Date(start);
      dt <= new Date(end);
      dt.setDate(dt.getDate() + 1)
    ) {
      arr.push(this.datePipe.transform(dt, 'yyyy-MM-dd'));
      this.dates.push(this.datePipe.transform(dt, 'yyyy-MM-dd'));
    }
    return arr;
  }

  onKeypressEvent(reset: any) {
    const element = window.document.getElementById('button');
    if (element != null) element.focus();
    this.search();
  }

  DownloadExcel() {
    this.isOk = true;
    this.isSpinning = true;
    if (this.totalRecords == 0) {
      this.isOk = false;
      this.isSpinning = false;
      this.message.error('There is No Data Found..', '');
    } else {
      this.api.getdramaMaster(0, 0, '', '', this.filterQuery).subscribe(
        (data) => {
          if (data['code'] == 200) {
            this.totalRecords = data['count'];
            this.listOfData1 = data['data'];
            console.log(this.Dramalistexcel, ' this.Dramalistexcel');
            this.isSpinning = false;
            const element = window.document.getElementById('downloadExcel');
            if (element != null) element.click();
          }
        },
        (err) => {
          console.log(err);
        }
      );
    }
  }
}
