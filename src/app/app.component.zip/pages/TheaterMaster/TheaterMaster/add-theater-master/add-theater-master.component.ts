import { Component, Input, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { TheaterMasterr } from 'src/app/Models/theatermaster';
import { ClientmasterService } from 'src/app/Services/clientmaster.service';

@Component({
  selector: 'app-add-theater-master',
  templateUrl: './add-theater-master.component.html',
  styleUrls: ['./add-theater-master.component.css']
})
export class AddTheaterMasterComponent implements OnInit {

  @Input()
  drawerClose!: Function;
  @Input()
  data:TheaterMasterr = new TheaterMasterr;
  @Input()
  drawerVisible: boolean = false;
  isSpinning = false;
  isOk=true;
  namepatt = /[a-zA-Z][a-zA-Z ]+/;
  city:TheaterMasterr[]=[]


  //Google map
  latitude: number=0;
  longitude: number=0;
  zoom = 12;
  // @Input() center: google.maps.LatLngLiteral={ lat: 16.867634, lng: 74.570389 };
  // markerOptions: google.maps.MarkerOptions = { draggable: true };
  // @Input() markerPositions: google.maps.LatLngLiteral ={ lat: 16.867634, lng: 74.570389 };

  // addMarker2(event: any) {
  //   this.markerPositions = event.latLng.toJSON();
  //   this.latitude = this.markerPositions.lat;
  //   this.longitude = this.markerPositions.lng;

  //   this.data.LATITUDE = this.latitude.toString();
  //   this.data.LONGITUDE   = this.longitude.toString();
  // }

  // googleMapPointer() {
  //   this.center = {
  //     lat: Number(this.data.LATITUDE),
  //     lng: Number(this.data.LONGITUDE  ),
  //   }
  //   this.markerPositions = { lat: Number(this.data.LATITUDE), lng: Number(this.data.LONGITUDE  ) };
  // }
//////


  constructor(private message: NzNotificationService,private api:ClientmasterService) { }

  ngOnInit(): void {

    this.getcity();
  }

  getcity(){
    this.isSpinning = true;
    this.api.getCityMaster(0, 0, '', '', ' AND STATUS=1').subscribe(data => {
      if (data['code'] == 200) {
        this.isSpinning = false;
        this.city= data["data"]
      }
    }, err => {
      console.log(err);
    })

  }
  
  close(): void {
    this.drawerClose();
  }

   //// Only number
   omit(event:any) {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  ////

  resetDrawer(websitebannerPage: NgForm) {
    this.data=new TheaterMasterr();
    websitebannerPage.form.markAsPristine();
    websitebannerPage.form.markAsUntouched();
  }

    //save
    save(addNew: boolean,websitebannerPage: NgForm): void {
      this.isSpinning = false;
      this.isOk=true;
       console.log(this.data.CITY_ID);
      console.log(this.data.LONGITUDE);
      console.log(this.data.LATITUDE);
      // console.log(this.data.ADDRESS);
      // console.log(this.data.EMAIL);
      // console.log(this.data.PIN_CODE);
  
      if(  
      this.data.CITY_ID == 0  &&
  
      this.data.NAME == "" &&
      this.data.ADDRESS == ""  
      // this.data.LONGITUDE == ""  &&
      // this.data.LATITUDE == ""  
      // this.data.SEQUENCE_NUMBER == 0 
      )
  
    
      {
        this.isOk=false;
        this.message.error("Please Fill All The Required Fields " ,"") 
     console.log("ok");
     
  
      }
  
  
      else if (this.data.CITY_ID == null || this.data.CITY_ID <=0) {
        this.isOk = false;
        this.message.error(' Please Select City Name', "");
      } 
      else if (this.data.NAME == null || this.data.NAME == "") {
        this.isOk = false;
        this.message.error(' Please Enter Theater Name', "");
  
      } 
     
    
      else if (this.data.ADDRESS == null || this.data.ADDRESS == "") {
        this.isOk = false;
        this.message.error(' Please Enter Theater Address', "");
  
      } 
     
      // else if (this.data.LONGITUDE == null || this.data.LONGITUDE == "") {
      //   this.isOk = false;
      //   this.message.error(' Please Enter Longitude', "");
  
      // } 
      // else if (this.data.LATITUDE == null || this.data.LATITUDE == "") {
      //   this.isOk = false;
      //   this.message.error(' Please Enter Lattitude', "");
  
      // } 


      else if(this.data.SEQUENCE_NUMBER== undefined || this.data.SEQUENCE_NUMBER<=0){
        this.isOk =false
        this.message.error('Please Enter Sequence Number.','')
      }

        // create update

     if (this.isOk) {
      this.isSpinning = true;
      {
          if (this.data.ID) {
            this.api.updateTheatreMaster(this.data).subscribe((successCode) => {
              if (successCode.code == '200') {
                this.message.success('Information Changed Successfully...', '');
                if (!addNew) this.drawerClose();
                this.isSpinning = false;
              } else {
                this.message.error('Information Has Not Changed...', '');
                this.isSpinning = false;
              }
            });
          }
          else{
            this.api.createTheatreMaster(this.data).subscribe((successCode) => {
              if (successCode.code == '200') {
                this.message.success('Information Entered Successfully...', '');
                if (!addNew) this.drawerClose();
                else {
                  this.data = new TheaterMasterr();
                  this.resetDrawer(websitebannerPage);
                  // this.data.IMG_URL= '';
                  
                  this.api.getTheatreMaster(1,1,'SEQUENCE_NUMBER','desc','').subscribe (data =>{
                    if (data['count']==0){
                      this.data.SEQUENCE_NUMBER=1;
                    }else
                    {
                      this.data.SEQUENCE_NUMBER=data['data'][0]['SEQUENCE_NUMBER']+1;
                    }
                  },err=>{
                    console.log(err);
                  })
                }
                this.isSpinning = false;
              } else {
                this.message.error('Failed To Fill Information...', '');
                this.isSpinning = false;
              }
            });
          }
        }
      }

    
    
 
  
    }

}
