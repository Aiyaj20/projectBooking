import { Component, OnInit } from '@angular/core';
import { NzTableQueryParams } from 'ng-zorro-antd/table';
import { TheaterMasterr } from 'src/app/Models/theatermaster';
import { ClientmasterService } from 'src/app/Services/clientmaster.service';

@Component({
  selector: 'app-theater',
  templateUrl: './theater.component.html',
  styleUrls: ['./theater.component.css']
})
export class TheaterComponent implements OnInit {


  drawerVisible!: boolean;
  drawerVisible1!: boolean;
  

  drawerTitle!: string;
  drawerData: TheaterMasterr = new TheaterMasterr();
  formTitle = " Theater List";
  dataList = [];
  loadingRecords = false;
  totalRecords = 1;
  pageIndex = 1;
  pageSize = 10;
  sortValue: string = "desc";
  sortKey: string = "id";
  searchText: string = "";
  filterQuery: string = "";
  isFilterApplied: string = "default";
  datacount: any;
  columns: string[][] = [["CITY_NAME", " City Name"], ["NAME", " Theater Name"],
  ["ADDRESS", "Theater Address"], ["LONGITUDE  ", " Longitude "], ["LATITUDE", " Latitude"], ["SEQUENCE_NUMBER", "Sequence No"], ["STATUS", "status"]];


  constructor(private api: ClientmasterService) { }

  ngOnInit(): void {
 
  }

  keyup(event: any) {
    this.search();
  }

  search(reset: boolean = false) {
    if (reset) {
      this.pageIndex = 1;
      this.sortKey = "id";
      this.sortValue = "desc"
    }
    // this.loadingRecords = true;
    var sort: string;
    try {
      sort = this.sortValue.startsWith("a") ? "asc" : "desc";
    } catch (error) {
      sort = "";
    }
    var likeQuery = "";
    console.log("search text:" + this.searchText);
    if (this.searchText != "") {
      likeQuery = " AND";
      this.columns.forEach(column => {
        likeQuery += " " + column[0] + " like '%" + this.searchText + "%' OR";
      });
      likeQuery = likeQuery.substring(0, likeQuery.length - 2)
      console.log("likeQuery" + likeQuery);
    }

    this.api.getTheatreMaster(this.pageIndex, this.pageSize, this.sortKey, sort, likeQuery).subscribe(data => {
      this.loadingRecords = false;
      this.totalRecords = data['count'];
      this.dataList = data['data'];
      if (this.totalRecords == 0) {
        data.SEQUENCE_NUMBER = 1;
      } else {
        data.SEQUENCE_NUMBER = this.dataList[this.dataList.length - 1]['SEQUENCE_NUMBER'] + 1
      }
    }, err => {
      console.log(err);
    });
  }

  //Drawer Methods
  get closeCallback() {
    return this.close.bind(this);
  }

  get closeCallback1() {
    return this.close1.bind(this);
  }
  add(): void {
    
    this.drawerTitle = "Add New Theater";
    this.drawerData = new TheaterMasterr();
    this.drawerData.STATUS = true;
    this.api.getTheatreMaster(1, 1, 'SEQUENCE_NUMBER', 'desc', '').subscribe(data => {
      if (data['count'] == 0) {
        this.drawerData.SEQUENCE_NUMBER = 1;
      } else {
        this.drawerData.SEQUENCE_NUMBER = data['data'][0]['SEQUENCE_NUMBER'] + 1;
      }
    }, err => {
      console.log(err);
    })




    this.drawerVisible = true;
  }







  edit(data: TheaterMasterr): void {

    this.drawerTitle = "Update Theater Details";
    this.drawerData = Object.assign({}, data);
    this.drawerVisible = true;
  }

  theaterId:any
  layoutDataList = []
  
  layout(data: TheaterMasterr): void {
  
    this.theaterId = data.ID
    
    this.api.getallTheatrelayout(0, 0, '', 'desc', ' AND THEATRE_ID ='+data.ID).subscribe(
      (data) => {
      if(data['code'] == 200){
        this.layoutDataList = data['data']
        console.log('ddd', this.layoutDataList)
      }
    }
  )
    this.layoutVisible = true;
  }
  
  drawerClose(): void {
    this.search();
    this.drawerVisible = false;
  }
  drawerClose1(): void {
    this.search();
    this.drawerVisible1 = false;
  }

  sort(params: NzTableQueryParams) {
    this.loadingRecords=true;
    const { pageSize, pageIndex, sort } = params;
    const currentSort = sort.find(item => item.value !== null);
    const sortField = (currentSort && currentSort.key) || 'id';
    const sortOrder = (currentSort && currentSort.value) || 'desc';
    console.log(currentSort)

    console.log("sortOrder :" + sortOrder)
    this.pageIndex = pageIndex;
    this.pageSize = pageSize;

    if (this.pageSize != pageSize) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
    }

    if (this.sortKey != sortField) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
    }

    this.sortKey = sortField;
    this.sortValue = sortOrder;
    this.search();
  }

  layoutVisible = false;



  close(): void {
    this.layoutVisible = false;
  }
  close1(): void {
    this.drawerClose();
  }

}
