import { Component, Input, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { appkeys } from 'src/app/app.constant';
import { Theatrelayoutmapping } from 'src/app/Models/theatrelayoutmapping';
import { Theatrelayoutmapping2 } from 'src/app/Models/Theatrelayoutmapping2';
import { ClientmasterService } from 'src/app/Services/clientmaster.service';

@Component({
  selector: 'app-layoutbuttondetails',
  templateUrl: './layoutbuttondetails.component.html',
  styleUrls: ['./layoutbuttondetails.component.css'],
})
export class LayoutbuttondetailsComponent implements OnInit {
  namepatt = /[a-zA-Z][a-zA-Z ]+/;
  constructor(
    private api: ClientmasterService,
    private message: NzNotificationService
  ) {}
  allMaster: any = [];
  isOk: boolean = false;
  isSpinning = false;
  screenwidth = window.innerWidth;
  @Input() drawerClose!: Function;
  @Input() layoutbuttonDataList = [];
  @Input() layoutbutton: any;
  @Input()
  data: Theatrelayoutmapping2 = new Theatrelayoutmapping2();
  @Input() theaterId: any;
  @Input() layoutmapId: any;
  loadingRecords = false;
  loadmodal = false;
  listReligionwithoutID = [];
  layoutbuttonDataList1 = [];
  editId: any;
  imgUrl = appkeys.retriveimgUrl;
  Imgurldata: string = '';
  ngOnInit(): void {
    this.getData();
    this.getData1();
  }
  omit(event: any) {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  getData() {
    this.loadingRecords = true;
    this.api
      .getallTheatrelayoutmapping(
        0,
        0,
        '',
        'desc',
        ' AND THEATRE_LAYOUT_MAPPING_ID =' + this.layoutbutton
      )
      .subscribe((data) => {
        if (data['code'] == 200) {
          this.loadingRecords = false;
          this.layoutbuttonDataList = data['data'];

          this.data.SEQUENCE_NUMBER =
            Number(this.layoutbuttonDataList.length) + 1;
        }
      });
  }

  getData1() {
    this.loadingRecords = true;
    this.api
      .getallTheatrelayoutmapping(
        0,
        0,
        '',
        'desc',
        ' AND THEATRE_LAYOUT_MAPPING_ID =' +
          this.layoutbutton +
          ' AND ID!=' +
          this.editId
      )
      .subscribe((data) => {
        if (data['code'] == 200) {
          this.loadingRecords = false;
          this.layoutbuttonDataList1 = data['data'];

          this.data.SEQUENCE_NUMBER =
            Number(this.layoutbuttonDataList1.length) + 1;
        }
      });
  }

  addData(addNew: boolean, form11: NgForm) {
    this.loadingRecords = false;
    this.isOk = true;
    this.data.THEATRE_LAYOUT_MAPPING_ID = this.layoutbutton;
    console.log(this.layoutbutton);
    if (
      this.data.ROW_NAME.trim() == '' &&
      this.data.START_SEAT_NUMBER <= 0 &&
      this.data.END_SEAT_NUMBER <= 0
    ) {
      this.isOk = false;
      this.message.error('Please Fill All Required Fields', '');
    } else if (
      this.data.THEATRE_LAYOUT_MAPPING_ID == null ||
      this.data.THEATRE_LAYOUT_MAPPING_ID == 0
    ) {
      this.isOk = false;
      this.message.error('Please Select Theater Name', '');
    } else if (
      this.data.ROW_NAME.trim() == '' &&
      this.data.ROW_NAME.trim() == ''
    ) {
      this.isOk = false;
      this.message.error('Please Enter Row Name', '');
    } else if (
      this.data.START_SEAT_NUMBER == null ||
      this.data.START_SEAT_NUMBER <= 0
    ) {
      this.isOk = false;
      this.message.error('Please Enter Start Seat Number ', '');
    } else if (
      this.data.END_SEAT_NUMBER == null ||
      this.data.END_SEAT_NUMBER <= 0
    ) {
      this.isOk = false;
      this.message.error('Please Enter End Seat Number', '');
    } else if (
      this.data.SEQUENCE_NUMBER == undefined ||
      this.data.SEQUENCE_NUMBER <= 0
    ) {
      this.isOk = false;
      this.message.error('Please Enter Sequence Number.', '');
    }

    // if (this.isOk) {
    //   this.isSpinning = true;
    //   {
    //     if (this.data.ID) {
    //       this.api
    //         .updateTheatrelayoutmapping(this.data)
    //         .subscribe((successCode) => {
    //           if (successCode.code == '200') {
    //             this.message.success('Information Updated Successfully', '');
    //             this.resetDrawer(form11);
    //             this.getData();

    //             this.isSpinning = false;
    //           } else {
    //             this.message.error('Information Not Updated', '');
    //             this.isSpinning = false;
    //           }
    //         });
    //     } else {
    //       this.api
    //         .createTheatrelayoutmapping(this.data)
    //         .subscribe((successCode) => {
    //           if (successCode.code == '200') {
    //             this.message.success('Information Save Successfully', '');
    //             // this.data = new Theatrelayoutmapping2();
    //             this.resetDrawer(form11);
    //             this.api
    //               .getallTheatrelayoutmapping(
    //                 1,
    //                 1,
    //                 'SEQUENCE_NUMBER',
    //                 'desc',
    //                 ''
    //               )
    //               .subscribe(
    //                 (data) => {
    //                   if (data['count'] == 0) {
    //                     this.data.SEQUENCE_NUMBER = 1;
    //                   } else {
    //                     this.data.SEQUENCE_NUMBER =
    //                       data['data'][0]['SEQUENCE_NUMBER'] + 1;
    //                   }
    //                 },
    //                 (err) => {
    //                   console.log(err);
    //                 }
    //               );
    //             this.getData();
    //           } else {
    //             this.message.error('Information Not Saved', '');
    //             this.isSpinning = false;
    //           }
    //         });
    //     }
    //   }
    // }

    if (this.isOk) {
      this.isSpinning = true;

      if (this.data.ID) {
        var religionID = this.layoutbuttonDataList.filter((obj) => {
          return obj['ROW_NAME'] == this.data.ROW_NAME;
        });
        if (religionID.length == 0) {
          this.api
            .updateTheatrelayoutmapping(this.data)
            .subscribe((successCode) => {
              if (successCode['code'] == '200') {
                console.log('successcode: ' + JSON.stringify(successCode));
                this.message.success('Information Updated Successfully', '');
                if (!addNew) this.resetDrawer(form11);
                this.getData();
                this.data = new Theatrelayoutmapping2();

                this.isSpinning = false;
              } else {
                this.message.error('Information Not Updated', '');
                this.isSpinning = false;
              }
            });
        } else {
          this.message.error(
            'Row Name Already Exist. Please Enter Other Row Name',
            ''
          );
          this.isSpinning = false;
        }
      } else {
        var religionData = this.layoutbuttonDataList.filter((obj) => {
          return obj['ROW_NAME'] == this.data.ROW_NAME;
        });

        if (religionData.length == 0) {
          this.api
            .createTheatrelayoutmapping(this.data)
            .subscribe((successCode) => {
              if (successCode['code'] == '200') {
                this.isSpinning = false;

                this.message.success('Information Saved Successfully', '');

                if (!addNew) {
                  this.drawerClose();
                } else {
                  this.resetDrawer(form11);
                  this.getData();
                  var countryData = this.layoutbuttonDataList.filter((obj) => {
                    return obj['ROW_NAME'] == this.data.ROW_NAME;
                  });
                  if (countryData.length == 0) {
                    this.data = new Theatrelayoutmapping2();
                  } else {
                    this.message.error(
                      'Row Name Already Exist. Please Enter Other Row Name',
                      ''
                    );
                    this.isSpinning = false;
                  }
                }
              } else {
                this.message.error('Information Not Saved', '');
                this.isSpinning = false;
              }
            });
        } else {
          this.message.error(
            'Row Name Already Exist. Please Enter Other Row Name',
            ''
          );
          this.isSpinning = false;
        }
      }
    }
  }

  alphaOnly(event: any) {
    event = event ? event : window.event;
    var charCode = event.which ? event.which : event.keyCode;
    if (
      charCode > 32 &&
      (charCode < 65 || charCode > 90) &&
      (charCode < 97 || charCode > 122)
    ) {
      return false;
    }
    return true;
  }
  edit(data: Theatrelayoutmapping2): void {
    this.data = Object.assign({}, data);
    this.api
      .getallTheatrelayoutmapping(
        0,
        0,
        '',
        'desc',
        ' AND THEATRE_LAYOUT_MAPPING_ID =' +
          this.layoutbutton +
          ' AND ID!=' +
          data.ID
      )
      .subscribe((data) => {
        if (data['code'] == 200) {
          this.loadingRecords = false;
          this.layoutbuttonDataList1 = data['data'];

          // this.data.SEQUENCE_NUMBER =
          //   Number(this.layoutbuttonDataList1.length) + 1;
        }
      });
    // this.drawerVisible = true;
  }

  isVisible = false;
  isOkLoading = false;
  
  showModal(): void {
    this.loadingRecords = true;
    this.Imgurldata=''
    console.log(this.Imgurldata);
    
    this.api
      .getlayoutgroupnameseatimage(this.layoutmapId, this.theaterId)
      .subscribe((data) => {
        if (data['code'] == 200) {
          this.loadmodal = true;
       
          setTimeout(()=>{
            this.Imgurldata = 'http://' + data['data']['preview_img'];
            this.loadmodal = false;
            console.log(this.Imgurldata);
          },5000);
          
          // this.Imgurldata = data['data']['preview_img'];
          console.log(this.Imgurldata);
          this.isVisible = true;
          this.loadingRecords = false;
        }
        else{
          this.message.error('Something Went Wrong',"")
        }
      });
  }

  handleOk(): void {
    this.isOkLoading = true;
    setTimeout(() => {
      this.isVisible = false;
      this.isOkLoading = false;
    }, 1000);
  }

  handleCancel(): void {
    this.isVisible = false;
  }

  close(): void {
    this.layoutbutton = false;
    this.drawerClose();
    console.log('Clicked');
  }

  get closeCallback() {
    return this.close.bind(this);
  }

  deletebooking(data: any) {
    console.log(data, 'Data');
    this.api
      .getmaster(0, 0, '', '', 'AND THEATRE_ID = ' + data.THEATRE_ID)
      .subscribe((data: any) => {
        this.allMaster = data['data'];
        console.log('allMaster', this.allMaster);
      });

    console.log(
      data.THEATRE_LAYOUT_MAPPING_ID,
      'data.THEATRE_LAYOUT_MAPPING_ID '
    );
    console.log(data.ID, 'data.ID ');
    this.api
      .deleteseatdeatils({
        THEATRE_LAYOUT_MAPPING_ID: data.THEATRE_LAYOUT_MAPPING_ID,
        ID: data.ID,
      })
      .subscribe((successCode) => {
        if (successCode.code == '200') {
          this.message.success('Seat Layout Deleted Succesfully', '');
          this.getData();
        } else {
          this.loadingRecords = false;
          this.message.error('Failed to Store Information', '');
        }
      });
  }

  resetDrawer(form11: NgForm) {
    this.data = new Theatrelayoutmapping2();
    form11.form.markAsPristine();
    form11.form.markAsUntouched();
  }
}
