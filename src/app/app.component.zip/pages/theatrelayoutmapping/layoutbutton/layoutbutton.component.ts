import { Component, Input, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { differenceInCalendarDays, setHours } from 'date-fns';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NzTableQueryParams } from 'ng-zorro-antd/table';
import { Theatremastercl } from 'src/app/Models/groupactivitylist';
import { SeatlayoutGroupNames } from 'src/app/Models/seatlayoutgroupname';
import { Theatrelayoutmapping } from 'src/app/Models/theatrelayoutmapping';
import { Theatrelayoutmapping2 } from 'src/app/Models/Theatrelayoutmapping2';
import { ClientmasterService } from 'src/app/Services/clientmaster.service';
@Component({
  selector: 'app-layoutbutton',
  templateUrl: './layoutbutton.component.html',
  styleUrls: ['./layoutbutton.component.css'],
})
export class LayoutbuttonComponent implements OnInit {
  current = new Date();
  allMaster: any = [];
  pageSize = 10;
  pageIndex = 1;
  sortKey: string = 'id';
  sortValue: string = 'desc';
  isSpinning = false;
  onlynumber = /^[0-9]*$/;
  screenwidth = window.innerWidth;
  drawerData1: Theatrelayoutmapping2 = new Theatrelayoutmapping2();
  LAYOUT_ID: number = 0;
  PRICE: number = 0;
  @Input()
  data: Theatrelayoutmapping = new Theatrelayoutmapping();
  layoutgrp: any = [];
  loadingRecords = false;
  @Input() theaterId: any;

  @Input()
  drawerClose!: Function;
  @Input()
  drawerClose1!: Function;
  theatremaster: Theatremastercl[] = [];
  @Input() layoutDataList = [];
  layoutDataList1 = [];
  layoutgrpnameimage = [];
  editId: any;
  isVisible = false;
  isOkLoading = false;
  isOk: boolean = false;
  seatlayoutgrpname: any = [];
  layoutmapId: number = 0;
  Imgurldata: string = '';
  loadmodal=false;
  constructor(
    private api: ClientmasterService,
    private message: NzNotificationService
  ) {}

  ngOnInit(): void {
    this.loadseatlayoutgrpname();

    console.log('111', this.layoutDataList);
    console.log('222', this.layoutDataList1);
  }

  disabledDate = (current: Date): boolean =>
    differenceInCalendarDays(current, this.current) < 0;

  loadseatlayoutgrpname() {
    this.api.getAllSeatlayoutgrpnames(0, 0, '', '', 'AND STATUS=1').subscribe(
      (data) => {
        this.seatlayoutgrpname = data['data'];
      },
      (err) => {
        console.log(err);
        this.isSpinning = false;
      }
    );
  }

  layoutbutton: any;
  layoutbuttonDataList = [];

  layoutbutton1(data: Theatrelayoutmapping): void {
    this.layoutbutton = data.ID;
    this.layoutmapId = data.ID;
    console.log(data.ID,'hasgdiasojdfckl');
    console.log(this.theaterId);
    this.layoutbuttonVisible = true;
   
      this.api
      .getallTheatrelayoutmapping(
        0,
        0,
        '',
        'desc',
        ' AND THEATRE_LAYOUT_MAPPING_ID  =' + data.ID
      )
      .subscribe((data) => {
        if (data['code'] == 200) {
          this.layoutbuttonDataList = data['data'];
        }
      });
    this.layoutbuttonVisible = true;
    this.api
      .getallTheatrelayoutmapping(
        1,
        1,
        'SEQUENCE_NUMBER',
        'desc',
        'AND STATUS=1'
      )
      .subscribe(
        (data) => {
          if (data['count'] == 0) {
            this.drawerData1.SEQUENCE_NUMBER = 1;
          } else {
            this.drawerData1.SEQUENCE_NUMBER =
              data['data'][0]['SEQUENCE_NUMBER'] + 1;
          }
        },
        (err) => {
          console.log(err);
        }
      );
    
  
  
  }

  layoutbuttonVisible = false;

  close(): void {
    this.layoutbuttonVisible = false;
    this.drawerClose();
    console.log('Clicked');
  }

  close1(): void {
    this.layoutbuttonVisible = false;
    // this.drawerClose();
    console.log('Clicked');
  }

  get closeCallback() {
    return this.close.bind(this);
  }
  get closeCallback1() {
    return this.close1.bind(this);
  }
  getData() {
    this.api
      .getallTheatrelayout(
        0,
        0,
        '',
        'desc',
        ' AND THEATRE_ID =' + this.theaterId
      )
      .subscribe((data) => {
        if (data['code'] == 200) {
          this.loadingRecords = false;
          this.layoutDataList = data['data'];
        }
      });
  }

  getData1() {
    this.api
      .getallTheatrelayout(
        0,
        0,
        '',
        'desc',
        ' AND THEATRE_ID =' + this.theaterId
      )
      .subscribe((data) => {
        if (data['code'] == 200) {
          this.loadingRecords = false;
          this.layoutDataList1 = data['data'];
        }
      });
  }

  addData(form11: NgForm) {
    this.loadingRecords = false;
    this.isOk = true;
    this.data.THEATRE_ID = this.theaterId;
    if (this.data.LAYOUT_ID <= 0 && this.data.DEFAULT_RATE <= 0) {
      this.isOk = false;
      this.message.error('Please Fill All Required Fields', '');
    } else if (this.data.THEATRE_ID == null || this.data.THEATRE_ID == 0) {
      this.isOk = false;
      this.message.error('Please Select Theater Name', '');
    } else if (this.data.LAYOUT_ID == null || this.data.LAYOUT_ID == 0) {
      this.isOk = false;
      this.message.error('Please Select Layout Group', '');
    } else if (this.data.DEFAULT_RATE == null || this.data.DEFAULT_RATE <= 0) {
      this.isOk = false;
      this.message.error('Please Enter Price', '');
    }

    // if (this.isOk) {
    //   this.isSpinning = true;

    //   {
    //     if (this.data.ID) {
    //       this.api.updateTheatrelayout(this.data).subscribe((successCode) => {
    //         if (successCode.code == '200') {
    //           this.message.success('Information Updated Successfully', '');
    //           this.getData();

    //           this.isSpinning = false;
    //         } else {
    //           this.message.error('Information Not Updated', '');
    //           this.isSpinning = false;
    //         }
    //       });
    //     } else {
    //       this.api.createTheatrelayout(this.data).subscribe((successCode) => {
    //         if (successCode.code == '200') {
    //           this.message.success('Information Save Successfully', '');

    //           this.getData();

    //           this.isSpinning = false;
    //         } else {
    //           this.message.error('Information Not Saved', '');
    //           this.isSpinning = false;
    //         }
    //       });
    //     }
    //   }
    // }

    if (this.isOk) {
      this.isSpinning = true;
      if (this.data.ID) {
        var religionID = this.layoutDataList.filter((obj) => {
          return obj['LAYOUT_ID'] == this.data.LAYOUT_ID;
        });
        if (religionID.length == 0) {
          this.api.updateTheatrelayout(this.data).subscribe((successCode) => {
            if (successCode['code'] == '200') {
              console.log('successcode: ' + JSON.stringify(successCode));
              this.message.success('Information Updated Successfully', '');

              this.isSpinning = false;
            } else {
              this.message.error('Information Not Updated', '');
              this.isSpinning = false;
            }
          });
        } else {
          this.message.error(
            'Religion Already Exist. Please Enter Other Religion Name',
            ''
          );
          this.isSpinning = false;
        }
      } else {
        var religionData = this.layoutDataList.filter((obj) => {
          return obj['LAYOUT_ID'] == this.data.LAYOUT_ID;
        });

        if (religionData.length == 0) {
          this.api.createTheatrelayout(this.data).subscribe((successCode) => {
            if (successCode['code'] == '200') {
              this.isSpinning = false;

              this.message.success('Information Saved Successfully', '');

              if ('') {
              } else {
                this.resetDrawer(form11);
                this.data = new Theatrelayoutmapping();
                this.getData();

                var countryData = this.layoutDataList.filter((obj) => {
                  return obj['LAYOUT_ID'] == this.data.LAYOUT_ID;
                });
                if (countryData.length == 0) {
                  this.data = new Theatrelayoutmapping();
                } else {
                  this.message.error(
                    'Layout Name Already Exist. Please Enter Other Layout Name',
                    ''
                  );
                  this.isSpinning = false;
                }
              }
            } else {
              this.message.error('Information Not Saved', '');
              this.isSpinning = false;
            }
          });
        } else {
          this.message.error(
            'Layout Already Exist. Please Enter Other Layout Name',
            ''
          );
          this.isSpinning = false;
        }
      }
    }
  }

  omit(event: any) {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  sort(params: NzTableQueryParams): void {
    this.loadingRecords = true;
    const { pageSize, pageIndex, sort } = params;
    const currentSort = sort.find((item) => item.value !== null);
    const sortField = (currentSort && currentSort.key) || 'id';
    const sortOrder = (currentSort && currentSort.value) || 'desc';
    console.log(currentSort);

    console.log('sortOrder :' + sortOrder);
    this.pageIndex = pageIndex;
    this.pageSize = pageSize;

    if (this.pageSize != pageSize) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
    }

    if (this.sortKey != sortField) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
    }

    this.sortKey = sortField;
    this.sortValue = sortOrder;
    this.getData();
  }

  onlynumdot(event: any) {
    console.log(event);

    event = event ? event : window.event;
    var charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 46 || charCode > 57)) {
      return false;
    }
    return true;
  }

  layoutid: any;
  isStarted = false;

  deletebooking(data: any) {
    console.log(data, 'Data');
    this.api
      .getmaster(0, 0, '', '', 'AND THEATRE_ID = ' + data.THEATRE_ID)
      .subscribe((data1: any) => {
        this.allMaster = data1['data'];
        for (let i = 0; i < this.allMaster.length; i++) {
          if (this.allMaster[i]['BOOKING_STATUS'] == 'S') {
            this.isStarted = true;
          } else {
            console.log('false1');
          }
        }
        if (this.isStarted == false) {
          console.log( data.LAYOUT_ID,)
          console.log( data.THEATRE_ID,)
          this.api
            .deletebookingmaster({
              LAYOUT_ID: data.LAYOUT_ID,
              THEATRE_ID: data.THEATRE_ID,
            })
            .subscribe((successCode) => {
              if (successCode.code == '200') {
                this.message.success('All Layout Group Has Been Cancelled', '');
                this.getData();
              } else {
                this.loadingRecords = false;
                this.message.error('Failed to Store Information', '');
              }
            });
        } else {
          // console.log('Already Started');
          this.message.error(
            'This Show is Presenting on Screen We Cannot Delete the Show ',
            ''
          );
        }
        console.log('allMaster', this.allMaster);
      });
    console.log(this.isStarted);
  }

  resetDrawer(form11: NgForm) {
    this.data = new Theatrelayoutmapping();
    form11.form.markAsPristine();
    form11.form.markAsUntouched();
  }

  showModal(): void {
    // this.isVisible = true;

    this.api
      .getlayoutgroupnameseatimage(this.layoutmapId, this.theaterId)
      .subscribe((data) => {
        this.Imgurldata=''
        if (data['code'] == 200) {
          this.loadmodal = true;
          setTimeout(()=>{
            this.Imgurldata = 'http://' + data['data']['preview_img'];
            this.loadmodal = false;
          },5000);
          
          console.log(this.Imgurldata);
          this.isVisible = true;
          this.loadingRecords = false;
        } else {
          this.message.error('Something Went Wrong', '');
        }
      });
  }

  handleOk(): void {
    this.isOkLoading = true;
    setTimeout(() => {
      this.isVisible = false;
      this.isOkLoading = false;
    }, 1000);
  }

  handleCancel(): void {
    this.isVisible = false;
  }
}
