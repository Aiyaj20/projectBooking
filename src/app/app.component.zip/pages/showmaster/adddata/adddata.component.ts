import { Component, OnInit, Input } from '@angular/core';
// import { Master } from 'src/app/Models/master';
import { Master } from 'src/app/Models/Show Master';
import { ClientmasterService } from 'src/app/Services/clientmaster.service';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NgForm } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { NzTableQueryParams } from 'ng-zorro-antd/table';
import { Theatrelayoutmapping } from 'src/app/Models/theatrelayoutmapping';
import { Theatrelayoutmapping2 } from 'src/app/Models/Theatrelayoutmapping2';
import { differenceInCalendarDays, setHours } from 'date-fns';

@Component({
  selector: 'app-adddata',
  templateUrl: './adddata.component.html',
  styleUrls: ['./adddata.component.css'],
})
export class AdddataComponent implements OnInit {
  onlynumber = /^[0-9]*$/;
  dateFormat = 'dd/MM/yyyy';
  // TIME: Date | null = null;
  defaultOpenValue = new Date(0, 0, 0, 0, 0, 0);
  loadmodal=false
  height: any = 200;
  width: any = 100;

  @Input() drawerClose!: Function;
  @Input() data: Master = new Master();
  @Input() layoutDataList = [];
  @Input() theaterId: any;
  screenwidth = window.innerWidth;
  loadingRecords = false;
  drawerData1: Theatrelayoutmapping2 = new Theatrelayoutmapping2();
  count: number = 0;
  details: any = [];
  detail: any = [];
  inputValue: any;
  isOkLoading = false;
  title = '';
  isVisible = false;
  @Input() drawerVisible = false;
  Imgurldata: string = '';
  isSpinning = false;
  isOk = true;
  end: any;
  log: any;
  theaterId2: any;
  currentDate:any
  constructor(
    public api: ClientmasterService,
    private message: NzNotificationService,
    private datePipe: DatePipe
  ) {}
  ngOnInit(): void {
    this.dramamasterget();
    this.theatermasterget();
    this.currentDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    console.log('this.currentDate',this.currentDate)
  }

  theatermasterget() {
    this.loadingRecords = true;
    this.api.getTheatreMaster(0, 0, '', 'asc', ' AND STATUS=1').subscribe(
      (data) => {
        if (data['code'] == 200) {
          this.loadingRecords = false;
          this.details = data['data'];
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  dramamasterget() {
    this.loadingRecords = true;
    this.theatermasterget();

    this.api.getdramaMaster(0, 0, '', 'asc', ' AND STATUS=1').subscribe(
      (data) => {
        if (data['code'] == 200) {
          this.loadingRecords = false;
          this.detail = data['data'];
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }
  close(): void {
    this.drawerClose();
  }
  omit(event: any) {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  resetDrawer(ShowProductform: NgForm) {
    this.data = new Master();
    ShowProductform.form.markAsPristine();
    ShowProductform.form.markAsUntouched();
  }

  //   tickects=[{LAYOUT_ID:
  //   ,
  // TICKET_RATE:number}];
  //save
  LAYOUT_ID: any;
  save(addNew: boolean, ShowProductform: NgForm): void {
    this.isSpinning = false;
    this.isOk = true;
    // for(let i=0;i<this.layoutdata.length;i++){
    // this.tickects.push(this.LAYOUT_ID:this.layoutdata.LAYOUT_ID)
    // }


    if (
      this.data.THEATRE_ID == 0 &&
      this.data.DRAMA_ID == 0 &&
      this.data.DATE == undefined &&
      this.data.START_TIME == undefined &&
      this.data.END_TIME == undefined &&
      this.data.BOOKING_STATUS == undefined &&
      this.data.TICKET_RATE == undefined
      // && this.data.TOTAL_SEATS== undefined
      // && this.data.AVAILABLE_SEATS== undefined
      // && this.data.BOOKED_SEATS== undefined
      // && this.data.TOTAL_REVENUE== undefined
    ) {
      this.isOk = false;

      this.message.error(' Please Fill All Required Fields ', '');
    } else if (this.data.THEATRE_ID == null || this.data.THEATRE_ID <= 0) {
      this.isOk = false;
      this.message.error('Please Select Theatre Name', '');
    } else if (this.data.DRAMA_ID == null || this.data.DRAMA_ID <= 0) {
      this.isOk = false;
      this.message.error('Please Select Drama Name', '');
    } else if (this.data.DATE == null || this.data.DATE == undefined) {
      this.isOk = false;
      this.message.error('Please Select Date', '');
    } else if (
      this.data.START_TIME == null ||
      this.data.START_TIME == undefined
    ) {
      this.isOk = false;
      this.message.error('Please Select Start Time', '');
    } else if (this.data.END_TIME == null || this.data.END_TIME == undefined) {
      this.isOk = false;
      this.message.error('Please Select End Time', '');
    } else if (
      this.data.BOOKING_STATUS == null ||
      this.data.BOOKING_STATUS == undefined
    ) {
      this.isOk = false;
      this.message.error('Please Select Booking Status', '');
    }
    else if (this.data.TICKET_RATE.length == undefined  || this.data.TICKET_RATE.length == 0) {
      this.isOk = false;
      this.message.error('Please Create Layout Group for Selected Theater Name', '');
    } 

    // else  if(this.data.TOTAL_SEATS<= 0 || this.data.TOTAL_SEATS==null){
    //   this.isOk =false
    //   this.message.error('Please Enter Total Seats','')
    // }else  if(this.data.AVAILABLE_SEATS<= 0 || this.data.AVAILABLE_SEATS==null){
    //   this.isOk =false
    //   this.message.error('Please Enter Available Seats','')
    // }
    // else  if(this.data.BOOKED_SEATS<= 0 || this.data.BOOKED_SEATS==null){
    //   this.isOk =false
    //   this.message.error('Please Enter Booked Seats','')
    // }else  if(this.data.TOTAL_REVENUE<= 0 || this.data.TOTAL_REVENUE==null){
    //   this.isOk =false
    //   this.message.error('Please Enter Total Revenue','')
    // }

    if (this.isOk) {
      this.isSpinning = true;

      if (this.data.DATE == undefined) {
        this.data.DATE = null;
      } else {
        this.data.DATE = this.datePipe.transform(this.data.DATE, 'yyyy-MM-dd');
      }
      if (this.data.START_TIME == undefined) {
        this.data.START_TIME = null;
      } else {
        this.data.START_TIME = this.datePipe.transform(
          this.data.START_TIME,
          'HH:mm'
        );
      }

      if (this.data.END_TIME == undefined) {
        this.data.END_TIME = null;
      } else {
        this.data.END_TIME = this.datePipe.transform(
          this.data.END_TIME,
          'HH:mm'
        );
      }
      if(this.currentDate == this.data.DATE){
        this.data.SHOW_STATUS = 'O'
      } else if(this.currentDate < this.data.DATE){
        this.data.SHOW_STATUS = 'U'
      }else{
      }
      if (this.data.ID) {
        this.api.updatedatamaster(this.data).subscribe((successCode) => {
          if (successCode.code == '200') {
            this.message.success(' Information Updated Successfully...', '');
            if (!addNew) this.drawerClose();
            this.isSpinning = false;
          } else {
            this.message.error(' Failed To Update Information...', '');
            this.isSpinning = false;
          }
        });
      } else {
        this.api
          .createDatamaster(this.data)
          // this.type=.TYPE_ID
          .subscribe((successCode) => {
            if (successCode.code == '200') {
              this.message.success(' Information Save Successfully...', '');
              if (!addNew) this.drawerClose();
              else {
                this.data = new Master();
                this.resetDrawer(ShowProductform);
                this.api.getmaster(1, 1, '', 'desc', '').subscribe(
                  (data) => {
                    if (data['count'] == 0) {
                      this.data.ID = 1;
                    } else {
                      this.data.ID = data['data'][0]['ID'] + 1;
                    }
                  },
                  (err) => {
                    console.log(err);
                  }
                );
              }
              this.isSpinning = false;
            } else {
              this.message.error(' Failed To Save Information...', '');
              this.isSpinning = false;
            }
          });
      }
    }
  }

  layoutbuttonVisible = false;
  layoutbutton: any;
  layoutbuttonDataList = [];
  layoutbutton1(data: Theatrelayoutmapping): void {
    this.layoutbutton = data.ID;
    this.layoutbuttonVisible = true;
    this.api
      .getallTheatrelayoutmapping(
        0,
        0,
        '',
        'desc',
        ' AND THEATRE_LAYOUT_MAPPING_ID  =' + data.ID
      )
      .subscribe((data) => {
        if (data['code'] == 200) {
          this.layoutbuttonDataList = data['data'];
        }
      });
    this.layoutbuttonVisible = true;
    this.api
      .getallTheatrelayoutmapping(1, 1, 'SEQUENCE_NUMBER', 'desc', '')
      .subscribe(
        (data) => {
          if (data['count'] == 0) {
            this.drawerData1.SEQUENCE_NUMBER = 1;
          } else {
            this.drawerData1.SEQUENCE_NUMBER =
              data['data'][0]['SEQUENCE_NUMBER'] + 1;
          }
        },
        (err) => {
          console.log(err);
        }
      );
  }

  filterlayout(event: any) {
    this.loadlayout();
    console.log('gdgd', event);
    this.loadingRecords = true;
    this.theaterId2 = this.data.THEATRE_ID;
    this.api
      .getallTheatrelayout(
        0,
        0,
        '',
        'asc',
        ' AND THEATRE_ID = ' + this.data.THEATRE_ID
      )
      .subscribe(
        (data) => {
          if (data['code'] == 200) {
            this.loadingRecords = false;
            this.layoutdata = data['data'];

            if (this.layoutdata.length > 0) {
              this.newArray = [];
              this.data.TOTAL_SEATS = 0;
              for (let i = 0; i < this.layoutdata.length; i++) {
                this.api
                  .getallTheatrelayoutmapping(
                    0,
                    0,
                    '',
                    'asc',
                    ' AND THEATRE_ID = ' +
                      this.data.THEATRE_ID +
                      ' AND LAYOUT_ID =' +
                      this.layoutdata[i]['LAYOUT_ID']
                  )
                  .subscribe((data) => {
                    if (data['code'] == 200) {
                      this.loadingRecords = false;
                      this.newArray.push(...data['data']);
                      let SumOfSeats = 0;
                      let sumofavilableseat = 0;
                      console.log(this.newArray);
                      if (this.newArray.length > 0) {
                        for (let k = 0; k < this.newArray.length; k++) {
                          SumOfSeats += Number(
                            this.newArray[k]['END_SEAT_NUMBER']
                          );
                          if (
                            this.newArray[k]['IS_AVAILABLE_FOR_BOOKING'] == 1
                          ) {
                            sumofavilableseat += Number(
                              this.newArray[k]['END_SEAT_NUMBER']
                            );
                          }
                        }
                        // this.getData();
                        this.data.TOTAL_SEATS = SumOfSeats;
                        this.data.AVAILABLE_SEATS = sumofavilableseat;
                        console.log(SumOfSeats);
                      }
                      console.log(this.newArray);
                    } else console.log('error');
                  });
              }
            } else {
              this.data.TOTAL_SEATS = 0;
              this.data.AVAILABLE_SEATS = 0;
            }
          }
        },
        (err) => {
          console.log(err);
          this.isSpinning = false;
        }
      );
  }
  layoutdata: any = [];
  loadlayout() {
    this.loadingRecords = true;
    this.api
      .getallTheatrelayout(
        0,
        0,
        '',
        'asc',
        ' AND THEATRE_ID = ' + this.data.THEATRE_ID
      )
      .subscribe(
        (data) => {
          if (data['code'] == 200) this.loadingRecords = false;
          this.layoutdata = data['data'];
          this.data.TICKET_RATE = this.layoutdata;
        },
        (err) => {
          console.log(err);
          this.isSpinning = false;
        }
      );
  }

  newArray: any[] = [];
  // getData() {
  //   this.data.TOTAL_SEATS = 0;
  //   this.loadingRecords = true;

  //   if (this.newArray.length > 0) {
  //     for (let k = 0; k <= this.newArray.length; k++) {
  //       this.data.TOTAL_SEATS += Number(this.newArray[k]['END_SEAT_NUMBER']);

  //       console.log(this.newArray[k]['END_SEAT_NUMBER']);
  //     }
  //     this.newArray = [];
  //   }

  //   // console.log(this.count);
  // }

  // getcount() {
  //   this.api
  //     .getallshowseatbookingdetails(
  //       0,
  //       0,
  //       '',
  //       'asc',
  //       ' AND SHOW_ID =' + this.showmasterid
  //     )
  //     .subscribe((data) => {
  //       if (data['code'] == 200) {
  //         this.showlayoutDataList = data['data'];

  //       } else {

  //       }
  //     });
  // }

  showModal(): void {
    console.log(this.theaterId2);
    console.log(this.data.THEATRE_ID);
    console.log(this.data.ID);
    this.theaterId2 = this.data.THEATRE_ID;
    if (this.theaterId2 == undefined || this.theaterId2==0) {
      this.message.warning('First Select Theater Name', '');
    } else {
     
      this.Imgurldata = '';
      if (this.data.ID == undefined) {
        this.api.getshowlayoutimage(this.theaterId2).subscribe((data) => {
          if (data['code'] == 200) {
            this.isVisible = true;
            this.loadmodal = true;
            setTimeout(()=>{
              this.Imgurldata = 'http://' + data['data']['preview_img'];
              this.loadmodal = false;
            },2000);
            console.log(this.Imgurldata);
          } else {
            this.message.error('Something Went Wrong', '');
          }
        });
      } else {
        this.Imgurldata = '';
        this.api.getshowlayoutimage(this.data.THEATRE_ID).subscribe((data) => {
          if (data['code'] == 200) {
            this.isVisible = true;
            this.loadmodal = true;
            setTimeout(()=>{
              this.Imgurldata = 'http://' + data['data']['preview_img'];
              this.loadmodal = false;
            },2000);
     
          
            console.log(this.Imgurldata);
          } else {
            this.message.error('Something Went Wrong', '');
          }
        });
      }
    }
  }


  editimage(){
    this.Imgurldata = '';
    this.api
    .getallshowseatbookingdetailsimage(
      0,
      0,
      '',
      'desc',
      ' AND SHOW_ID =' + this.data.ID,
      this.data.ID
    )
    .subscribe((data) => {
      if (data['code'] == 200) {
        this.isVisible = true;
        this.loadmodal = true;
        setTimeout(()=>{
          this.Imgurldata = 'http://' + data['data']['layout_img'];
          this.loadmodal = false;
        },2000);

        // this.Imgurldata = 'http://' + data['data']['preview_img'];
        // console.log(this.ImageUrl);
      }
      else {
        this.message.error('Something Went Wrong', '');
      }
    });
  }

  // showModal(data: Theatrelayoutmapping2): void {
  //   this.layoutbutton = data.ID;

  //   this.api
  //     .getlayoutgroupnameseatimage(

  //         this.layoutmapId,
  //         this.theaterId
  //     )
  //     .subscribe((data) => {
  //       if (data['code'] == 200) {
  //         this.Imgurldata = 'http://' + data['data']['preview_img'];
  //         // this.Imgurldata = data['data']['preview_img'];
  //         console.log( this.Imgurldata )
  //       }
  //     });

  //   this.isVisible = true;
  // }

  handleOk(): void {
    this.isOkLoading = true;
    setTimeout(() => {
      this.isVisible = false;
      this.isOkLoading = false;
    }, 3000);
  }

  handleCancel(): void {
    this.isVisible = false;
  }

  todays = new Date();

  disabled = (current: Date): boolean =>
    differenceInCalendarDays(current, this.todays) < 0;
}
