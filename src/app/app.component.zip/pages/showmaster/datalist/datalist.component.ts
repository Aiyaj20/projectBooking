import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NzTableQueryParams } from 'ng-zorro-antd/table';
import { Master } from 'src/app/Models/Show Master';
import { ClientmasterService } from 'src/app/Services/clientmaster.service';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { SeatlayoutGroupNames } from 'src/app/Models/seatlayoutgroupname';
import { differenceInCalendarDays, setHours } from 'date-fns';
import * as moment from 'moment';

@Component({
  selector: 'app-datalist',
  templateUrl: './datalist.component.html',
  styleUrls: ['./datalist.component.css'],
})
export class DatalistComponent implements OnInit {
  showmasterid: any;
  drawerVisible = false;
  drawerTitle: any;
  pageSize = 10;
  pageIndex = 1;
  isOk: boolean = false;
  allMaster: any = [];
  // Products: any= []
  Masterdetails: Master = new Master();
  interval: any;
  sortKey: string = 'id';
  sortValue: string = 'desc';
  searchText: any = '';
  loadingRecords = true;
  statuss:boolean=false
  filterQuery: string = '';
  totalRecords: any;

  startValue: any;
  endValue: any;
  endOpen = false;
  startOpen = false;
  previewavail: any;
  filterClass: string = 'filter-invisible';
  isSpinning = false;
  isFilterApplied: any = 'default';
  isOngoingApplied: any = 'default';
  isUpcomingApplied: any = 'default';
  isCompletedApplied: any = 'default';
  today2 = new Date();
  today =
    new Date().getFullYear().toString() +
    '-' +
    (new Date().getMonth() + 1).toString() +
    '-' +
    new Date().getDate().toString();

  current = new Date();
  month = this.today;
  type: any;
  showStatus: string = '';
  THEATRE_ID = [];

  dataList: any[] = [];
  dataList1: any[] = [];

  columns: string[][] = [
    ['THEATRE_NAME', 'Theater_Name'],
    ['DRAMA_NAME', 'Drama_Name'],
    ['DATE', 'Date'],
    ['START_TIME', 'Stime'],
    ['END_TIME', 'Etime'],
    ['BOOKING_STATUS', 'BOOKING_STATUS'],
    ['TOTAL_SEATS', 'Total_seats'],
    ['AVAILABLE_SEATS', 'Available_seats'],
    ['BOOKED_SEATS', 'Booked_seats'],
    ['TOTAL_REVENUE', 'Total_revenue'],
  ];

  drawerOpen() {
    this.Masterdetails = new Master();
    this.drawerVisible = true;
    this.drawerTitle = 'Add New Show Master';
  }

  drawerClose() {
    this.search();
    this.drawerVisible = false;
  }

  get closeCallback() {
    return this.drawerClose.bind(this);
  }
  changeBoolean(s:any) {
   this.statuss = s
  }

  get closeboolean() {
    return this.changeBoolean.bind(this);
  }

  ngOnInit(): void {
    this.search(true);
    //  this.onGet();
    this.api.getTheatreMaster(0, 0, '', '', ' AND STATUS=1').subscribe(
      (data) => {
        if (data['code'] == 200) {
          this.dataList1 = data['data'];
        }
      },
      (err) => {
        console.log(err);
      }
    );
  }

  sort(params: NzTableQueryParams): void {
    const { pageSize, pageIndex, sort } = params;
    const currentSort = sort.find((item) => item.value !== null);
    const sortField = (currentSort && currentSort.key) || 'id';
    const sortOrder = (currentSort && currentSort.value) || 'desc';
    console.log(currentSort);

    console.log('sortOrder :' + sortOrder);
    this.pageIndex = pageIndex;
    this.pageSize = pageSize;

    if (this.pageSize != pageSize) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
    }

    if (this.sortKey != sortField) {
      this.pageIndex = 1;
      this.pageSize = pageSize;
    }

    this.sortKey = sortField;
    this.sortValue = sortOrder;
    this.search();
  }

  constructor(
    public api: ClientmasterService,
    private datePipe: DatePipe,
    private message: NzNotificationService,
    private notify: NzNotificationService
  ) {}

  onGet() {
    this.api
      .getmaster(this.pageIndex, this.pageSize, 'NAME', '', this.filterQuery)
      .subscribe((data: any) => {
        this.allMaster = data['data'];
        console.log(this.allMaster);
      });
  }

  edit(data: Master) {
    let newArray = [];
    console.log(data['RATE_ARRAY']);
    this.drawerTitle = 'Update Show Details';
    this.Masterdetails = Object.assign({}, data);
    console.log(this.Masterdetails);

    this.Masterdetails.START_TIME = new Date(
      '01-01-1970 ' + this.Masterdetails.START_TIME
    );
    this.Masterdetails.END_TIME = new Date(
      '01-01-1970 ' + this.Masterdetails.END_TIME
    );

    let RATE_ARRAY1 = JSON.parse(data['RATE_ARRAY']);
    for (let i = 0; i < RATE_ARRAY1.length; i++) {
      newArray.push({
        DEFAULT_RATE: RATE_ARRAY1[i]['AMOUNT'],
        LAYOUT_NAME: RATE_ARRAY1[i]['GROUP_LAYOUT_NAME'],
        LAYOUT_ID: RATE_ARRAY1[i]['LAYOUT_ID'],
      });
    }
    this.Masterdetails.TICKET_RATE = newArray;
    console.log(newArray);

    // this.Masterdetails .START_TIME=this.datePipe.transform(this.Masterdetails .START_TIME,"HH:mm:ss");
    // this.Masterdetails .END_TIME=this.datePipe.transform(this.Masterdetails .END_TIME,"HH:mm:ss");

    this.Masterdetails.START_TIME = new Date(this.Masterdetails.START_TIME);
    this.Masterdetails.END_TIME = new Date(this.Masterdetails.END_TIME);

    this.drawerVisible = true;
    
  }

  keyup(event: any) {
    this.search();
  }

  search(reset: boolean = false) {
    if (reset) {
      this.pageIndex = 1;
      this.sortKey = 'id';
      this.sortValue = 'desc';
    }
    this.loadingRecords = true;
    var sort: string;
    try {
      sort = this.sortValue.startsWith('a') ? 'asc' : 'desc';
    } catch (error) {
      sort = '';
    }
    var likeQuery = '';
    console.log('search text:' + this.searchText);
    if (this.searchText != '') {
      likeQuery = ' AND';
      this.columns.forEach((column) => {
        likeQuery += ' ' + column[0] + " like '%" + this.searchText + "%' OR";
      });
      likeQuery = likeQuery.substring(0, likeQuery.length - 2);
      console.log('likeQuery' + likeQuery);
    }
    this.api
      .getmaster(
        this.pageIndex,
        this.pageSize,
        this.sortKey,
        sort,
        this.filterQuery + likeQuery
      )
      .subscribe(
        (data) => {
          if (data['code'] == 200) {
            this.loadingRecords = false;
            this.totalRecords = data['count'];
            this.allMaster = data['data'];

            // if(this.totalRecords==0){
            //   data.SEQUENCE_NO=1;
            // }
          } else {
            this.message.error('Something Went Wrong', '');
            this.loadingRecords = false;
          }
        },
        (err) => {
          console.log(err);
        }
      );
  }
  getTimeIn12Hour(time: any) {
    return this.datePipe.transform(new Date(), 'yyyy-MM-dd' + ' ' + time);
  }

  showlayoutDataList = [];
  ShowCountsdata = [];
  showlayoutVisible = false;
  ImageUrl: string = '';

  layout(data: SeatlayoutGroupNames): void {
    this.showmasterid = data.ID;
    this.previewavail = data;
    this.showlayoutVisible = true;
    this.api
      .getallshowseatbookingdetails(0, 0, '', 'asc', ' AND SHOW_ID =' + data.ID)
      .subscribe((data) => {
        if (data['code'] == 200) {
          this.showlayoutDataList = data['data'];
          this.ShowCountsdata = data['summaryCounts'];
        }
      });
    this.showlayoutVisible = true;

    this.api
      .getallshowseatbookingdetailsimage(
        0,
        0,
        '',
        'desc',
        ' AND SHOW_ID =' + data.ID,
        data.ID
      )
      .subscribe((data) => {
        if (data['code'] == 200) {
          this.ImageUrl = 'http://' + data['data']['layout_img'];
          console.log(this.ImageUrl);
        }
      });
    this.showlayoutVisible = true;
  }

  close(): void {
    this.showlayoutVisible = false;
  }
  get closeCallback1() {
    return this.close.bind(this);
  }
  //filter apply

  dates: any = [];

  disabledEndDate2 = (current: Date): any => {
    let index = this.dates.findIndex(
      (date: any) => date === moment(current).format('YYYY-MM-DD')
    );
    return index === -1 && true;
  };

  startDateChange() {
    var startDate = this.datePipe.transform(this.startValue, 'yyyy-MM-dd');
    var endDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');

    console.log(this.getDaysArray(startDate, endDate));
    console.log(this.dates);
  }

  getDaysArray(start: any, end: any) {
    for (
      var arr = [], dt = new Date(start);
      dt <= new Date(end);
      dt.setDate(dt.getDate() + 1)
    ) {
      arr.push(this.datePipe.transform(dt, 'yyyy-MM-dd'));
      this.dates.push(this.datePipe.transform(dt, 'yyyy-MM-dd'));
    }
    return arr;
  }

  timeDefaultValue = setHours(new Date(), 0);

  // disabledStartDate2 = (current: Date): boolean =>
  //   differenceInCalendarDays(current, this.today2) > 0;

  moduleStartDateHandle(open: boolean) {
    if (!open) {
      this.endOpen = true;
    }
  }

  applyFilter() {
    console.log('show1:', this.startValue);
    console.log('show2:', this.endValue);
    console.log('show3:', this.type);
    console.log('show4:', this.showStatus);
    this.loadingRecords = true;
    var sort: string;
    try {
      sort = this.sortValue.startsWith('a') ? 'asc' : 'desc';
    } catch (error) {
      sort = '';
    }
    this.startValue = this.datePipe.transform(this.startValue, 'yyyy-MM-dd');
    this.endValue = this.datePipe.transform(this.endValue, 'yyyy-MM-dd');
    //////////////////////
    if (
      this.startValue != undefined &&
      this.endValue != undefined &&
      this.type != undefined
    ) {
      this.filterQuery =
        " AND DATE between '" +
        this.startValue +
        "' AND '" +
        this.endValue +
        "' " +
        ' AND THEATRE_ID =' +
        this.type +
        " AND SHOW_STATUS = '" +
        this.showStatus +
        "'";
      this.filterClass = 'filter-invisible';
    } else if (
      this.startValue != undefined &&
      this.endValue != undefined &&
      this.type != undefined &&
      this.showStatus != ''
    ) {
      this.isFilterApplied = 'primary';
      this.filterQuery =
        " AND DATE between '" +
        this.startValue +
        "' AND '" +
        this.endValue +
        "' " +
        ' AND THEATRE_ID=' +
        this.type +
        " AND SHOW_STATUS = '" +
        this.showStatus +
        "'";
      this.filterClass = 'filter-invisible';
    } else if (
      this.startValue != undefined &&
      this.endValue != undefined &&
      this.type != undefined &&
      this.showStatus == ''
    ) {
      this.isFilterApplied = 'primary';
      this.filterQuery =
        " AND DATE between '" +
        this.startValue +
        "' AND '" +
        this.endValue +
        "' " +
        ' AND THEATRE_ID =' +
        this.type;
      this.filterClass = 'filter-invisible';
    } else if (
      this.startValue != undefined &&
      this.endValue != undefined &&
      this.type == undefined &&
      this.showStatus != ''
    ) {
      this.isFilterApplied = 'primary';
      this.filterQuery =
        " AND DATE between '" +
        this.startValue +
        "' AND '" +
        this.endValue +
        "' " +
        " AND SHOW_STATUS = '" +
        this.showStatus +
        "'";
      this.filterClass = 'filter-invisible';
    } else if (
      this.startValue == undefined &&
      this.endValue == undefined &&
      this.type != undefined &&
      this.showStatus != ''
    ) {
      this.isFilterApplied = 'primary';
      this.filterQuery =
        ' AND THEATRE_ID=' +
        this.type +
        " AND SHOW_STATUS = '" +
        this.showStatus +
        "'";
      this.filterClass = 'filter-invisible';
    } else if (
      this.startValue == undefined &&
      this.endValue == undefined &&
      this.type == undefined &&
      this.showStatus != ''
    ) {
      this.isFilterApplied = 'primary';
      this.filterQuery = " AND SHOW_STATUS = '" + this.showStatus + "'";
      this.filterClass = 'filter-invisible';
    } else if (
      this.startValue == undefined &&
      this.endValue == undefined &&
      this.type != undefined &&
      this.showStatus == ''
    ) {
      this.isFilterApplied = 'primary';
      this.filterQuery = ' AND THEATRE_ID = ' + this.type;
      this.filterClass = 'filter-invisible';
    } else if (
      this.startValue != undefined &&
      this.endValue != undefined &&
      this.type == undefined &&
      this.showStatus == ''
    ) {
      this.isFilterApplied = 'primary';
      this.filterQuery =
        " AND DATE between '" +
        this.startValue +
        "' AND '" +
        this.endValue +
        "' ";
      this.filterClass = 'filter-invisible';
    } else if (this.startValue == undefined && this.endValue != undefined) {
      this.notify.error('', 'Please Select Start Date');
    } else if (this.startValue != undefined && this.endValue == undefined) {
      this.notify.error('', 'Please Select End Date');
    } else {
      this.isFilterApplied = 'primary';
      this.filterQuery =
        " AND DATE between '" +
        this.startValue +
        "' AND '" +
        this.endValue +
        "' ";
      this.filterClass = 'filter-invisible';
    }
    //////////////////////

    // if (
    //   this.startValue != undefined &&
    //   this.endValue != undefined &&
    //   this.type != undefined &&
    //   this.showStatus != ''
    // ) {
    //   this.isFilterApplied = 'primary';
    //   this.filterQuery =
    //     " AND DATE between '" +
    //     this.startValue +
    //     "' AND '" +
    //     this.endValue +
    //     "' " +
    //     ' AND THEATRE_ID=' +
    //     this.type +
    //     " AND SHOW_STATUS = '" + this.showStatus + "'";
    //   this.filterClass = 'filter-invisible';
    // } else
    //   if (
    //     this.startValue != undefined &&
    //     this.endValue != undefined &&
    //     this.type == undefined &&
    //     this.showStatus != ''
    //   ) {
    //     this.isFilterApplied = 'primary';
    //     this.filterQuery =
    //       " AND DATE between '" +
    //       this.startValue +
    //       "' AND '" +
    //       this.endValue +
    //       "' " +
    //       " AND SHOW_STATUS = '" + this.showStatus + "'";
    //     this.filterClass = 'filter-invisible';
    //   } else
    //     if (
    //       this.startValue != undefined &&
    //       this.endValue != undefined &&
    //       this.type != undefined &&
    //       this.showStatus == ''
    //     ) {
    //       this.isFilterApplied = 'primary';
    //       this.filterQuery =
    //         " AND DATE between '" +
    //         this.startValue +
    //         "' AND '" +
    //         this.endValue +
    //         "' " +
    //         ' AND THEATRE_ID=' +
    //         this.type;
    //       this.filterClass = 'filter-invisible';
    //     } else if (this.startValue != undefined && this.endValue != undefined) {
    //       this.isFilterApplied = 'primary';
    //       this.filterQuery =
    //         " AND DATE between '" +
    //         this.startValue +
    //         "' AND '" +
    //         this.endValue +
    //         "' ";
    //       this.filterClass = 'filter-invisible';
    //     } else if (
    //       this.type != undefined &&
    //       this.startValue == undefined &&
    //       this.endValue == undefined &&
    //       this.showStatus == ''
    //     ) {
    //       this.filterQuery = 'AND THEATRE_ID=' + '' + this.type;
    //       this.filterClass = 'filter-invisible';

    //     } else if (
    //       this.type == undefined &&
    //       this.startValue == undefined &&
    //       this.endValue == undefined &&
    //       this.showStatus != ''
    //     ) {
    //       this.filterQuery = " AND SHOW_STATUS = '" + this.showStatus + "'";
    //       this.filterClass = 'filter-invisible';

    //     } else if (this.startValue == undefined && this.endValue != undefined) {
    //       this.notify.error('', 'Please Enter Start Date');

    //     } else if (this.endValue == undefined && this.startValue != undefined) {
    //       this.notify.error('', 'Please Enter End Date');

    //     } else if (
    //       this.startValue != undefined &&
    //       this.type != undefined &&
    //       this.endValue == undefined &&
    //       this.showStatus != ''
    //     ) {
    //       this.notify.error('', 'Please Enter End Date');

    //     } else if (
    //       this.endValue != undefined &&
    //       this.type != undefined &&
    //       this.startValue == undefined
    //     ) {
    //       this.notify.error('', 'Please Enter Start Date');

    //     } else {
    //       this.notify.error('', 'Please Select Any Filter Value');
    //     }
    ///local
    this.api
      .getmaster(
        this.pageIndex,
        this.pageSize,
        this.sortKey,
        sort,
        this.filterQuery
      )
      .subscribe(
        ///////publish
        // this.service.getAllContra(0,0,this.sortKey,sort,this.filterQuery + " AND TRANSACTION_TYPE_ID=2").subscribe(

        ///Live
        // this.service.getAllContra(0,0,this.sortKey,sort,this.filterQuery + " AND TRANSACTION_TYPE_ID=2").subscribe(

        (data) => {
          this.loadingRecords = false;
          this.dataList = data['data'];
          this.totalRecords = data['count'];
          this.allMaster = data['data'];

          console.log(this.dataList);
        },
        (err) => {
          console.log(err);
        }
      );
    // this.filterClass='filter-invisible';
  }

  clearFilter() {
    this.filterClass = 'filter-invisible';
    this.dataList = [];
    this.startValue = null;
    this.endValue = null;
    this.filterQuery = '';
    this.month = this.today;
    this.type = null;
    this.isFilterApplied = 'default';
    this.isCompletedApplied = 'default';
    this.isOngoingApplied = 'default';
    this.isUpcomingApplied = 'default';
    this.showStatus = '';
    this.search();
  }
  onKeypressEvent(reset: any) {
    const element = window.document.getElementById('button');
    if (element != null) element.focus();
    this.search();
  }

  showFilter() {
    if (this.filterClass === 'filter-visible')
      this.filterClass = 'filter-invisible';
    else this.filterClass = 'filter-visible';
  }

  DownloadExcel() {
    this.isOk = true;
    this.isSpinning = true;
    if (this.totalRecords == 0) {
      this.isOk = false;
      this.isSpinning = false;
      this.message.error('There is No Data Found..', '');
    } else {
      this.api.getmaster(0, 0, '', '', this.filterQuery).subscribe(
        (data) => {
          if (data['code'] == 200) {
            this.totalRecords = data['count'];
            this.allMaster = data['data'];
            this.isSpinning = false;
            const element = window.document.getElementById('downloadExcel');
            if (element != null) element.click();
          }
        },
        (err) => {
          console.log(err);
        }
      );
    }
  }

  disabledStartDate2 = (current: Date): boolean =>
    differenceInCalendarDays(current, this.startValue) < 0;

  onGoingShow(event: any) {
    // console.log('value',event)
    // this.clearFilter();
    this.showStatus = 'O';
    this.isFilterApplied = 'primary';
    this.isOngoingApplied = 'primary';
    this.isUpcomingApplied = 'default';
    this.isCompletedApplied = 'default';

    this.startValue = null;
    this.endValue = null;
    this.type = null;
    // if (
    //   this.startValue != undefined &&
    //   this.endValue != undefined &&
    //   this.type != undefined
    // ) {
    //   this.startValue == undefined;
    //   this.endValue == undefined;
    //   this.type == undefined;
    // } else if (this.startValue != undefined && this.endValue != undefined) {
    //   this.startValue == undefined;
    //   this.endValue == undefined;
    // } else if (this.startValue != undefined) {
    //   this.startValue == undefined;
    // } else if (this.endValue != undefined) {
    //   this.endValue == undefined;
    // } else if (this.type != undefined) {
    //   this.type == undefined;
    // } else {
    // }

    this.applyFilter();
  }
  upcomingShow(event: any) {
    // this.clearFilter();
    this.showStatus = 'U';
    this.isFilterApplied = 'primary';
    this.isOngoingApplied = 'default';
    this.isUpcomingApplied = 'primary';
    this.isCompletedApplied = 'default';
    this.startValue = null;
    this.endValue = null;
    this.type = null;
    // if (
    //   this.startValue != undefined ||
    //   this.endValue != undefined ||
    //   this.type != undefined
    // ) {
    //   this.startValue == undefined;
    //   this.endValue == undefined;
    //   this.type == undefined;
    // } else {
    // }
    this.applyFilter();
  }
  completeShow(event: any) {
    // this.clearFilter();
    this.isFilterApplied = 'primary';
    this.isCompletedApplied = 'primary';
    this.isUpcomingApplied = 'default';
    this.isOngoingApplied = 'default';
    this.showStatus = 'C';
    this.startValue = null;
    this.endValue = null;
    this.type = null;
    // if (
    //   this.startValue != undefined ||
    //   this.endValue != undefined ||
    //   this.type != undefined
    // ) {
    //   this.startValue == undefined;
    //   this.endValue == undefined;
    //   this.type == undefined;
    // } else {
    // }
    this.applyFilter();
  }
}
